
from . import product
from . import res_config_settings