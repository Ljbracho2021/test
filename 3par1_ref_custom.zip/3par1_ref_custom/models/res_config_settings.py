# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    generar_ref = fields.Boolean("Generar referencia interna", help="Generar la referencia interna del producto",
                                 implied_group='product_expiry.group_expiry_date_on_delivery_slip')
    
