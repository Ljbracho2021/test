
import itertools

from odoo import api, fields, models, tools, _, SUPERUSER_ID
from odoo.exceptions import ValidationError, RedirectWarning, UserError

class ProductTemplate(models.Model):
    #_inherit = "product.template"
    _inherit = "product.template"

    def _get_ref_interna(self):

        code = self.env['ir.sequence'].next_by_code('product.template')
        return code
    
    def _get_prefix(self, categID):
        prefijo = self.env['product.category'].search([('id', '=',categID)])
        if prefijo:
            code = prefijo.prefix
        else:
            code = False 
        return code

    @api.model
    def create(self, vals):
        categID = vals.get('categ_id')
        prefix = self._get_prefix(categID)
        #raise ValidationError(_('self.prefix:'+str(prefix)))
        referencia = ""
        
        ref    = self._get_ref_interna()

        if prefix:
            referencia = prefix + "-" + ref
        else:
            referencia = "RI-" + ref

        vals['default_code'] = referencia 

        if not vals.get('barcode'):
            vals['barcode'] = vals['default_code']

        res = super(ProductTemplate, self).create(vals)
        return res
    
class ProductCategory(models.Model):
    #_inherit = "product.category"
    _inherit = "product.category"

    prefix = fields.Char('Prefijo', index=True, help="Valor del prefijo para la referencia interna")

    #--------------------------------------------------------------------------------#
    #  VALIDACIONES PARA EL PREFIJO                                                  #
    #--------------------------------------------------------------------------------#
    @api.onchange('prefix')
    def _onchange_prefix(self):
        if not self.prefix:
            return
        
        self.prefix = self.prefix.upper()

        digito = self.prefix.isalnum()
        if not digito:
            aux = self.prefix
            
            return {'warning': {
                'title': ("Mensaje de Error:"), 
                'message': ("Error: El prefijo debe contener solo valores alfanumérico..! "), 
            }}

        if len(self.prefix) > 5:
            aux = self.prefix
            
            return {'warning': {
                'title': ("Mensaje de Error:"), 
                'message': ("Error: El prefijo debe contener hasta 5 caracteres..! "), 
            }}

        domain = [('prefix', '=', self.prefix)]
        if self.id.origin:
               domain.append(('id', '!=', self.id.origin))
        
        if self.env['product.category'].search(domain, limit=1):
               aux_prefix = self.prefix
               
               return {'warning': {
                        'title': ("Mensaje de Error:"), 
                        'message': ("Error: El prefijo ya existe..! "), 
                       }}