
import itertools

from odoo import api, fields, models, tools, _, SUPERUSER_ID
from odoo.exceptions import ValidationError, RedirectWarning, UserError

class Product(models.Model):
    #_inherit = "product.template"
    _inherit = "product.template"

    @tools.ormcache()
    def _get_ref_interna(self):
        # Deletion forbidden (at least through unlink)
        return self.env.ref('res.config.settings.serie_ref')

    @api.onchange('name')
    def _onchange_name(self):
        self.default_code = "10000"

        serie = self._get_ref_interna
        return {'warning': {
                'title': _("Note:" + str(serie)),
                'message': _("The Internal Reference '%s' already exists.", self.default_code),
            }}
    
    #@api.depends('name')
    #def _asignar_ref(self):
        #main_company = self.env['res.company']._get_main_company()
        #for template in self:
            #template.default_code = "10000"

        #self.default_code = "10000"

    