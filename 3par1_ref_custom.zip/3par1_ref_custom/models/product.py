
import itertools

from odoo import api, fields, models, tools, _, SUPERUSER_ID
from odoo.exceptions import ValidationError, RedirectWarning, UserError

class ProductTemplate(models.Model):

    #_inherit = "product.template"
    _inherit = "product.template"

    
    #def _get_ref_interna(self):

    #    code = self.env['ir.sequence'].next_by_code('product.template')
    #    return code

    @api.model
    def create(self, vals):
        
        vals['default_code'] = self.env['ir.sequence'].next_by_code('product.template') 

        if not vals.get('barcode'):
            vals['barcode'] = vals['default_code']

        res = super(ProductTemplate, self).create(vals)
        return res