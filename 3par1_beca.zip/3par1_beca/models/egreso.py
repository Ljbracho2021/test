# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class BecaEgreso(models.Model):
    _name        = 'beca.egreso'
    _description = 'Gestion beca - egreso'
    _rec_name    = 'name'

    name = fields.Char(string='Año', required=True)   

    