
from odoo import api, fields, models

class BecaWanularn(models.Model):
    _name        = 'beca.wanularn'
    _description = 'Gestion de Becas - Permite registrt el eMail'
    

    name         = fields.Char(string='Número Cédula')   
    