# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models


class BecaTemporal(models.Model):
    _name        = 'beca.temporal'
    _description = 'Gestión de Becas - Temporal'
    _rec_name    = 'numero'
  
    numero       = fields.Char(string='Numero', required = True)
  
    