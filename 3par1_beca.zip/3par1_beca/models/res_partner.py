# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _

class res_partner(models.Model):
    _inherit = 'res.partner'

    is_propietario        = fields.Boolean(string='Propietario')
    is_person             = fields.Boolean(string="Persona")
    is_vigilancia_company = fields.Boolean(string='Insurance Company')
    is_institution        = fields.Boolean('Institution')
    reference             = fields.Char('ID Number')