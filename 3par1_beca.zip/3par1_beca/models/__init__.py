# -*- coding: utf-8 -*-

from . import estado
from . import municipio
from . import parroquia
from . import planilla

from . import carrera
from . import universidad
from . import registro
from . import wanularn






