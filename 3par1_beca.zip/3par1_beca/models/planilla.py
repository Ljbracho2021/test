# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class BecaPlanilla(models.Model):
    _name        = 'beca.planilla'
    _description = 'Gestión de Becas - planilla'
    _rec_name    = 'name'

    name         = fields.Char(string='Nro.', required=True, copy=False, readonly=True, default=lambda self: _('New'))   
    numero       = fields.Char(string='Número Planilla', required = True)

    cedula       = fields.Char(string='Cédula Identidad', required = True)
    apellido1    = fields.Char(string='1er. Apellido', required = True)
    apellido2    = fields.Char(string='2do. Apellido')
    nombre1      = fields.Char(string='1er. Nombre', required = True)
    nombre2      = fields.Char(string='2do. Nombre')
    
    date_nacimiento = fields.Date(string="Fecha Nacimiento", required=True)
    estado_id    = fields.Many2one('beca.estado', store=True)
    municipio_id = fields.Many2one('beca.municipio', store=True, required = True)
    parroquia_id = fields.Many2one('beca.parroquia', store=True, required = True)

    direccion    = fields.Char(string='Dirección', required = True)
    telefono1    = fields.Char(string='Teléfono 1', required = True)
    telefono2    = fields.Char(string='Teléfono 2')

    opcion1_id   = fields.Many2one('beca.carrera', store=True, required = True, string='Opción 1')
    opcion2_id   = fields.Many2one('beca.carrera', store=True, required = True, string='Opción 2')
    opcion3_id   = fields.Many2one('beca.carrera', store=True, required = True, string='Opción 3')


    #candidato_id = fields.Many2one('beca.candidato', string="Candidato", required= True)

    # apellido1     = fields.Char(string='Apellido', related='candidato_id.apellido1',required = True, store=True)
    # apellido2     = fields.Char(string='Apellido', related='candidato_id.apellido2',required = True, store=True)
    # nombre1       = fields.Char(string='Nombre', related='candidato_id.nombre1',required = True, store=True)
    # nombre2       = fields.Char(string='Nombre', related='candidato_id.nombre2',required = True, store=True)
    # cedula       = fields.Char(string='Cédula', related='candidato_id.cedula',required = True, store=True)
    # date_nacimiento = fields.Date(string="Fecha de nacimiento", related='candidato_id.date_nacimiento', required=True)
    # estado_id    = fields.Many2one(string='Estado', related='candidato_id.estado_id', store=True)
    # municipio_id = fields.Many2one(string='Municipio', related='candidato_id.municipio_id', store=True)
    # parroquia_id = fields.Many2one(string='Parroquia', related='candidato_id.parroquia_id', store=True)
    # direccion    = fields.Char(string='Dirección', related='candidato_id.direccion', required = True,store=True)
    anoegreso    = fields.Date(string='Año Egreso Bachiller', required = True)

    modalidad = fields.Selection([
        ('0', 'Presencial'),
        ('1', 'Virtual'),
    ], required=True, default='0', tracking=True, string='Opciones de Estudio')
    
    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Favorito'),
    ], required=True, default='0', tracking=True)

    active = fields.Boolean(
        'Active', default=True,
        help="If unchecked, it will allow you to hide the product without removing it.")
    note = fields.Text(string="Observaciones")

    state = fields.Selection([('en estudio', 'EN ESTUDIO'), ('aprobada', 'APROBADA'),
                              ('en proceso', 'EN PROCESO'), ('ejecutada', 'EJECUTADA'), ('cancelada', 'CANCELADA')], default='en estudio',
                             string="Status", tracking=True)     

    def action_aprobar(self):
        self.state = 'aprobada'

    def action_proceso(self):
        self.state = 'en proceso'

    def action_done(self):
        self.state = 'ejecutada'

    def action_draft(self):
        self.state = 'en estudio'

    def action_cancel(self):
        self.state = 'cancelada'  


    @api.onchange('numero')
    def _onchange_numero(self):
        if not self.numero:
            return

        domain = [('numero', '=', self.numero)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['beca.planilla'].search(domain, limit=1):
            aux_numero = self.numero
            self.numero = ""
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("Número de Planilla ya existe  ", aux_numero), 
            }}

    @api.onchange('cedula')
    def _onchange_cedula(self):
        if not self.cedula:
            return

        domain = [('cedula', '=', self.cedula)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['beca.planilla'].search(domain, limit=1):
            aux_cedula = self.cedula
            self.cedula = ""
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("Número de Cédula de identidad ya existe  ", aux_cedula), 
            }}
        

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('beca.planilla') or _('New')
        res = super(BecaPlanilla, self).create(vals)
        return res
