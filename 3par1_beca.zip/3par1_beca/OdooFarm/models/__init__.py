from . import specie, animal, production, stock, animal_group
from . import abstract_event, weaning_event, pregnancy_diagnosis_event
from . import semen_extration_event, farrowing_event, foster_event
from . import removal_event, abort_event, insemination_event
from . import feed_abstract_event, medication_event, event_order
from . import transformation_event, feed_event, feed_inventory, move_event
from . import product, res_company, purchse_analytics, analitic_sales
from . import account_invoice, consume_stock