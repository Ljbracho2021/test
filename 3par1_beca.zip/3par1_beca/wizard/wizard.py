# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class Wizard(models.Model):
    _name = 'beca.wizard'
    _description = 'beca Wizard'

    def action_search_salida(self):
        form_data = self.read()[0]
        
        salida    = []

        becadoSet     = self.env['beca.planilla'].search([], order ='cedula asc')

        usuarioCreate  = self.env['res.users'].search([])
        usuarioBuscar  = self.env['res.users']

        for indice in becadoSet: 

            cedula  = indice.cedula

            if cedula:
                encontroCedula = usuarioBuscar.search_count([('name','=',cedula)])
                if not encontroCedula:

                       nuevo          = usuarioCreate.create({'name'  : cedula,
                                                              'login' : cedula,
                                                             })

        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return