# -*- coding: utf-8 -*-

from . import wizard
from . import wizardb
from . import wizards
from . import wizardc
from . import wizardm
from . import wizardp
from . import wizardtp