# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class Wizard(models.TransientModel):
    _name = 'analytic.wizardc'
    _description = 'analytic Wizardc'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    
    #nombre_parroquia = fields.Char(string='Nombre', related='comuna_id.parroquia_id.nombre', readonly=True, store=True)
    
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]
        
        salida    = []

        municipioSet     = self.env['beca.municipio'].search([], order ='nombre asc')

        municipioCreate  = self.env['analytic.beca'].search([])
        municipioCreate.unlink()

        for indice in municipioSet: 

            municipio  = indice.nombre

            if municipio != "TODOS LOS MUNICIPIOS":
                                
                cantPublica = self.env['beca.planilla'].search_count([('municipio_id','=',indice.id),('modalidad','=','0'),('state','=','becado')])
                cantPrivada = self.env['beca.planilla'].search_count([('municipio_id','=',indice.id),('modalidad','=','1'),('state','=','becado')])
                cantVirtual = self.env['beca.planilla'].search_count([('municipio_id','=',indice.id),('modalidad','=','2'),('state','=','becado')])
                totalPlani  = cantPublica + cantPrivada + cantVirtual

                publica = cantPublica
                privada = cantPrivada
                virtual = cantVirtual
                total   = totalPlani

                nuevo          = municipioCreate.create({'nombre'  : municipio,
                                                         'publica' : publica,
                                                         'privada' : privada,
                                                         'virtual' : virtual,
                                                         'total'   : total,
                                                        })

        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        #return self.env.ref('analyticBeca.action_analytic_municipio').report_action(self, data=data)
        return