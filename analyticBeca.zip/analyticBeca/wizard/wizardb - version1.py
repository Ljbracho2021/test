# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import calendar, datetime
import random

class WizardA(models.TransientModel):
    _name = 'analytic.wizardb'
    _description = 'analytic Wizardb'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    cantidadPublica  = fields.Integer(string="Cantidad Modalidad PÙBLICA", required=True, default=0)
    cantidadPrivada  = fields.Integer(string="Cantidad Modalidad PRIVADA", required=True, default=0)
    cantidadVirtual  = fields.Integer(string="Cantidad Modalidad VIRTUAL", required=True, default=0)
      
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)


    def action_search_reiniciar(self):
        form_data = self.read()[0]
        salida    = []
        
        planillaSet     = self.env['beca.temporal'].search([('state', '=', 'becado')])

        for indice in planillaSet: 

              encontro = self.env['beca.temporal'].search([('numero', '=', indice.numero)], limit=1) 
              if encontro: 
                 
                 #raise ValidationError(_("Encontro la planilla:" + auxNumero))
                 
                 cadena = str(encontro)
                 pos = cadena.find(",")
                 direccion = cadena[14:pos] 
                 registro = self.env['beca.temporal'].browse(direccion)
                 #raise ValidationError(_("Nombre planilla:" +  direccion))
                 registro.state = 'censado'
     
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return 
        
#-------------------------------------------------------------------------------------------
#
#-------------------------------------------------------------------------------------------
    def action_search_salida(self):
        form_data = self.read()[0]
        salida    = []
        
        #-------------------------------------------------------------------------------------------
        #  PUBLICA
        #-------------------------------------------------------------------------------------------
        contaPublica = 0
        contaPrivada = 0
        contaVirtual = 0

        seguir = True

        while seguir:

              numero = (random.randint(1,70000))
              auxNumero = str(numero)

              if len(auxNumero) <= 7:
                 aux = len(auxNumero)
                 falta = 7-aux

                 for i in range(falta):
                     auxNumero = "0" + str(auxNumero) 

              auxNumero = "PC-" + auxNumero
 
              encontro = self.env['beca.planilla'].search([('numero', '=', auxNumero),('state', '=', 'censado')], limit=1) 
              if encontro: 
                 #raise ValidationError(_("Encontro la planilla:" + auxNumero))
                 cadena = str(encontro)
                 pos = cadena.find(",")
                 direccion = cadena[14:pos] 

                 if encontro.modalidad == '0':
                    #raise ValidationError(_("Encontro la planilla Publica:" + auxNumero))
                    if contaPublica < self.cantidadPublica:

                       registro = self.env['beca.planilla'].browse(direccion)
                       registro.state = 'becado'
                       contaPublica = contaPublica + 1

                 if encontro.modalidad == '1':
                    #raise ValidationError(_("Encontro la planilla Privada:" + auxNumero))
                    if contaPrivada < self.cantidadPrivada:
 
                       registro = self.env['beca.planilla'].browse(direccion)
                       registro.state = 'becado'
                       contaPrivada = contaPrivada + 1

                 if encontro.modalidad == '2': 
                       #raise ValidationError(_("Encontro la planilla Virtual:" + auxNumero))
                       if contaVirtual < self.cantidadVirtual:
 
                          registro = self.env['beca.planilla'].browse(direccion)
                          registro.state = 'becado'
                          contaVirtual = contaVirtual + 1

              if contaPublica==self.cantidadPublica and contaPrivada==self.cantidadPrivada and contaVirtual==self.cantidadVirtual:
                 seguir = False

                 
   
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return 
        #return self.env.ref('analyticeBeca.action_analytic_a').analytic_action(self, data=data)