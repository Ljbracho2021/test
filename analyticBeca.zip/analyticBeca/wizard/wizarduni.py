# -*- coding: utf-8 -*-

from email.policy import default

from pkg_resources import require
from odoo import api, fields, models
import calendar, datetime

class WizardUni(models.TransientModel):
    _name = 'analytic.wizarduni'
    _description = 'Wizarduni'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    
 
    def primer_dia_mes(self):
        now   = datetime.datetime.now()
        year  = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now   = datetime.datetime.now()
        year  = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]
        salida = []

        planillaSet     = self.env['beca.planilla'].search([('modalidad','=','2')])

        registroCreate  = self.env['beca.registro'].search([])
        registroCreate.unlink()

        for indice in planillaSet: 
            auxN1     = ""
            auxN2     = ""
            auxA1     = ""
            auxA2     = ""

            cedula    = indice.cedula
            auxN1     = indice.nombre1
            auxA1     = indice.apellido1

            if indice.nombre2:
                auxN2     = indice.nombre2
            
            if indice.apellido2:
                auxA2     = indice.apellido2

            nombre    = auxN1 + ' ' + auxN2 + ', ' + auxA1 + ' ' + auxA2
            modalidad = 'VIRTUAL'
            condicion = 'BECADO'

            nuevo     = registroCreate.create({
                                                        'cedula' : cedula,
                                                        'nombre'  : nombre,
                                                        'modalidad' : modalidad,
                                                        'condicion'  : condicion
                                              })       
 
 
 
 
 
 
 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        #return self.env.ref('reporteSala.action_report_uni').report_action(self, data=data)
        return