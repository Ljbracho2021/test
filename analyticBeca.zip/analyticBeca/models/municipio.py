# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class Becaamunicipio(models.Model):
    _name        = 'analytic.municipio'
    _description = 'Gestión beca - amunicipio'
    _rec_name    = 'nombre'
    _order       = 'nombre'


    nombre  = fields.Char('Municipio', required = True, readonly=True)
    censado = fields.Integer('Total Cesado', readonly=True)
    anulada = fields.Integer('Total Anulada', readonly=True)
    becado  = fields.Integer('Total Becado', readonly=True)
    total   = fields.Integer('Total Planillas', readonly=True)
    publica = fields.Integer('Modalidad Pùblica', readonly=True)
    privada = fields.Integer('Modalidad Privada', readonly=True)
    virtual = fields.Integer('Modalidad Virtual', readonly=True)
   