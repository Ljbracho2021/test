# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class Becaamunicipio(models.Model):
    _name        = 'analytic.beca'
    _description = 'Gestión beca - AnalyticBeca'
    _rec_name    = 'nombre'
    _order       = 'nombre'

    nombre  = fields.Char('Municipio', required = True, readonly=True)
    publica = fields.Integer('Modalidad Pùblica', readonly=True)
    privada = fields.Integer('Modalidad Privada', readonly=True)
    virtual = fields.Integer('Modalidad Virtual', readonly=True)
    total   = fields.Integer('Total Becas', readonly=True)
   