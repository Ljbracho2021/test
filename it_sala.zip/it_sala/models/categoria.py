# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaCategoria(models.Model):
    _name = 'sala.categoria'
    _description = 'Gestión Gobierno - categoria'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)
   
    parent_id = fields.Many2one('sala.categoria', 'categoria Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.categoria', 'parent_id', 'categoriaS HIJOS')
    complete_name = fields.Char('Categoria', compute='_compute_complete_name', recursive=True, store=True)     
    sector_id = fields.Many2one('sala.sector', 'Sector')
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for categoria in self:
            if categoria.parent_id:
                categoria.complete_name = '%s / %s' % (categoria.parent_id.complete_name, categoria.nombre)
            else:
                categoria.complete_name = categoria.nombre

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
         if self.nombre:
            self.nombre = self.nombre.upper()
         return
