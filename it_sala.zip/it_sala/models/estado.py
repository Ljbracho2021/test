# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaEstado(models.Model):
    _name = 'sala.estado'
    _description = 'Gestión Gobierno - Estados'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
    municipio_ids = fields.One2many('sala.municipio', 'estado_id', string="Municipio")
    
    @api.onchange('nombre')
    def _onchange_nombre(self):
         
        if self.nombre:
            self.nombre = self.nombre.upper()
        
        domain = [('nombre', '=', self.nombre)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.estado'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El nombre para el Estado ya existe ", self.nombre), 
            }}