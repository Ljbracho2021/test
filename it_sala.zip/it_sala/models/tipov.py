# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaTipov(models.Model):
    _name = 'sala.tipov'
    _description = 'Gestión Gobierno - Tipo vulnerabilidad'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)
   
    parent_id = fields.Many2one('sala.tipov', 'tipov Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.tipov', 'parent_id', 'accionS HIJOS')
    complete_name = fields.Char('Tipo acción', compute='_compute_complete_name', recursive=True, store=True)     
   
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for tipov in self:
            if tipov.parent_id:
                tipov.complete_name = '%s / %s' % (tipov.parent_id.complete_name, tipov.nombre)
            else:
                tipov.complete_name = tipov.nombre

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
        if self.nombre:
            self.nombre = self.nombre.upper()
        
        domain = [('nombre', '=', self.nombre)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.tipov'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El nombre para el tipo de Vulnerabilidad ya existe ", self.nombre), 
            }}