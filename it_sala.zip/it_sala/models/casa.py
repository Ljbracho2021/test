# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaCasa(models.Model):
    _name = 'sala.casa'
    _description = 'Gestión Gobierno - casas de Gobierno'
    _rec_name = 'nombre'
    _order = 'calle_id'
  
    nombre = fields.Char('Casa', required = True)

    estado_id = fields.Many2one('sala.estado', 'Estado', default=1)
    municipio_id = fields.Many2one('sala.municipio', 'Municipio',default=1)
    comuna_id = fields.Many2one('sala.comuna', 'Comuna')
    comunidad_id = fields.Many2one('sala.comunidad', 'Comunidad')
    calle_id = fields.Many2one('sala.calle', 'Calle')
   
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    tipo = fields.Selection([
        ('casa', 'CASA'),
        ('quinta', 'QUINTA'),
        ('rancho', 'RANCHO'),
        ('galpon', 'GALPON'),
        ('otro', 'OTRO'),
        ], required=True, tracking=True) 

    
    direccion = fields.Char('Calle/Av/Nro.')
    note = fields.Text('Observaciones')

    familia_ids = fields.One2many('sala.familia', 'casa_id', string="Familias")

    familia_count = fields.Integer(string='Nro. Familias', compute='_compute_familia_count')
    familia_conta = fields.Integer('Nro. Familias', default=0)

    def _compute_familia_count(self):
        for rec in self:
            # familia_count = self.env['sala.familia'].search_count([('casa_id.calle_id.comunidad_id.comuna_id', '=', rec.id)])
            familia_count = self.env['sala.familia'].search_count([('casa_id', '=', rec.id)])
            rec.familia_count = familia_count
            rec.familia_conta = familia_count

    habita_count = fields.Integer(string='Nro. Habitantes', compute='_compute_habita_count')
    habita_conta = fields.Integer('Nro. Habitantes', default=0)      
    def _compute_habita_count(self):
        for rec in self:
            habita_count = self.env['familia.persona.lines'].search_count([('familia_id.casa_id', '=', rec.id)])
            rec.habita_count = habita_count
            rec.habita_conta = habita_count

    @api.onchange('nombre')
    def _onchange_nombre(self):
         if self.calle_id:
            self.comuna_id=self.calle_id.comunidad_id.comuna_id
            self.comunidad_id=self.calle_id.comunidad_id
            return 