# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaOrganizacion(models.Model):
    _name = 'sala.organizacion'
    _description = 'Gestión Gobierno - Organizacion'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
   
    territorio_id = fields.Many2one('sala.territorio', 'Territorio')
    complete_name = fields.Char('Ubicación', related='territorio_id.complete_name', tracking=True, store=True)
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    clasificacion = fields.Selection([
        ('consejo comunal', 'CONSEJO COMUNAL'),
        ('clap', 'CLAP'), 
        ('ubch', 'UBCH'),
    ], 'Clasificación', required=True, default='consejo comunal', tracking=True)
    persona_line_ids = fields.One2many('organizacion.persona.lines', 'organizacion_id',
                                            string="Persona Lines")

class OrganizacionLiderLines(models.Model):
    _name = "organizacion.persona.lines"
    _description = "Organizaciones / Lideres Lines"

    persona_id = fields.Many2one('sala.persona', 'Lider')
    rol = fields.Selection([
        ('formador', 'FORMADOR'),
        ('vocero', 'VOCERO'), 
        ('articulador territorial', 'ARTICULADOR TERRITORIAL'),
    ], 'Rol', required=True, default='vocero', tracking=True)
    
    organizacion_id = fields.Many2one('sala.organizacion', string="Organizacion")
