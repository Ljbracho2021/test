# -*- coding: utf-8 -*-
from random import randint

from odoo import models, fields, api

class SalaUnidad(models.Model):
    _name = 'sala.unidad'
    _description = 'Gestión Gobierno - Unidad'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'nombre_cor'
    _order = 'complete_name'
  
    nombre = fields.Char('Nombre', required = True)
    nombre_cor = fields.Char('Nombre Corto', required = True)    
   
    parent_id = fields.Many2one('sala.unidad', 'unidad Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.unidad', 'parent_id', 'accionS HIJOS')
    complete_name = fields.Char('Unidad', compute='_compute_complete_name', recursive=True, store=True)     
   
    active = fields.Boolean(string="Active", default=True)
    note = fields.Text('Observaciones')

    accion_ids = fields.One2many('acciong.lines', 'unidad_id', string="Acciones de gobierno")

    accion_count = fields.Integer(string='Nro. acciones', compute='_compute_accion_count')
    accion_conta = fields.Integer('Nro. Acciones', default=0)
    def _compute_accion_count(self):
        for rec in self:
            accion_count = self.env['acciong.lines'].search_count([('unidad_id', '=', rec.id)])
            rec.accion_count = accion_count
            rec.accion_conta = accion_count

    def _get_default_color(self):
        return randint(1, 11)
    color = fields.Integer(string='Color', default=_get_default_color)
   
    @api.depends('nombre', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for unidad in self:
            if unidad.parent_id:
                unidad.complete_name = '%s / %s' % (unidad.parent_id.complete_name, unidad.nombre)
            else:
                unidad.complete_name = unidad.nombre

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
        if self.nombre:
            self.nombre = self.nombre.upper()
        
        domain = [('nombre', '=', self.nombre)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.unidad'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El nombre para la Unidad administrativa ya existe ", self.nombre), 
            }}

