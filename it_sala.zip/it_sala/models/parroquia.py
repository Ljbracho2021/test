# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaParroquia(models.Model):
    _name = 'sala.parroquia'
    _description = 'Gestión Gobierno - Parroquia'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)

    estado_id = fields.Many2one('sala.estado', 'Estado')
    municipio_id = fields.Many2one('sala.municipio', 'Municipio')
    image = fields.Image(max_width=100, max_height=100, store=True)
    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Favorito'),
    ], required=True, default='0', tracking=True)
    active = fields.Boolean(
        'Active', default=True,
        help="If unchecked, it will allow you to hide the product without removing it.")

    comunidad_ids = fields.One2many('sala.comunidad', 'parroquia_id', string="Comunidades")
    accion_ids = fields.One2many('acciong.lines', 'parroquia_id', string="Acciones de gobierno")

    comuna_count = fields.Integer(string='Nro. Comunas', compute='_compute_comuna_count')
    comuna_conta = fields.Integer('Nro. Comunas', default=0)
    def _compute_comuna_count(self):
        for rec in self:
            comuna_count = self.env['sala.comuna'].search_count([('parroquia_id', '=', rec.id)])
            rec.comuna_count = comuna_count
            rec.comuna_conta = comuna_count
        
    comunidad_count = fields.Integer(string='Nro. Comunidades', compute='_compute_comunidad_count')
    comunidad_conta = fields.Integer('Nro. Comunidades', default=0)
    def _compute_comunidad_count(self):
        for rec in self:
            comunidad_count = self.env['sala.comunidad'].search_count([('parroquia_id', '=', rec.id)])
            rec.comunidad_count = comunidad_count
            rec.comunidad_conta = comunidad_count

    accion_count = fields.Integer(string='Nro. Acciones de gobierno', compute='_compute_accion_count')
    accion_conta = fields.Integer('Nro. Acciones', default=0)
    def _compute_accion_count(self):
        for rec in self:
            accion_count = self.env['sala.acciong'].search_count([('parroquia_id', '=', rec.id)])
            rec.accion_count = accion_count   
            rec.accion_conta = accion_count 

    habita_count = fields.Integer(string='Nro. Habitantes', compute='_compute_habita_count')
    habita_conta = fields.Integer('Nro. Habitantes', default=0)
    def _compute_habita_count(self):
        for rec in self:
            habita_count = self.env['sala.persona'].search_count([('parroquia_id', '=', rec.id)])
            rec.habita_count = habita_count
            rec.habita_conta = habita_count
    
    familia_count = fields.Integer(string='Nro. Familias', compute='_compute_familia_count')
    familia_conta = fields.Integer('Nro. Familias', default=0)
    def _compute_familia_count(self):
        for rec in self:
            familia_count = self.env['sala.persona'].search_count([('parroquia_id', '=', rec.id),('is_jefe', '=', 'true')])
            rec.familia_count = familia_count
            rec.familia_conta = familia_count

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
        if self.nombre:
            self.nombre = self.nombre.upper()
        
        domain = [('nombre', '=', self.nombre)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.parroquia'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El nombre para la Parroquia ya existe ", self.nombre), 
            }}