# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaUbicacion(models.Model):
    _name = 'sala.ubicacion'
    _description = 'Gestión Gobierno - Ubicaciones'
    _parent_name = "parent_id"
    _parent_store = True
    _rec_name = 'complete_name'
    _order = 'complete_name' 

    name = fields.Char('Nombre', index=True, required=True)
 
    complete_name = fields.Char('Ubicacion', compute='_compute_complete_name', recursive=True, store=True)

    parent_id = fields.Many2one('sala.ubicacion', 'Ubicación Padre', index=True, ondelete='cascade')
    parent_path = fields.Char(index=True)
    child_id = fields.One2many('sala.ubicacion', 'parent_id', 'UBICACIONES HIJAS')
    active = fields.Boolean(string="Active", default=True)
    
    territorio_count = fields.Integer('# Territorios' , compute='_compute_territorio_count', 
                                      help="El numero de territorios de esta ubicacion (Does not consider the children categories)")

    @api.depends('name', 'parent_id.complete_name')
    def _compute_complete_name(self):
        for ubicacion in self:
            if ubicacion.parent_id:
                ubicacion.complete_name = '%s / %s' % (ubicacion.parent_id.complete_name, ubicacion.name)
            else:
                ubicacion.complete_name = ubicacion.name

    def _compute_territorio_count(self):
        read_group_res = self.env['sala.territorio'].read_group([('ubicacion_id', 'child_of', self.ids)], ['ubicacion_id'], ['ubicacion_id'])
        group_data = dict((data['ubicacion_id'][0], data['ubicacion_id_count']) for data in read_group_res)
        for ubicacion in self:
            territorio_count = 0
            for sub_ubicacion_id in ubicacion.search([('id', 'child_of', ubicacion.ids)]).ids:
                territorio_count += group_data.get(sub_ubicacion_id, 0)
            ubicacion.territorio_count = territorio_count

   




  
    @api.constrains('parent_id')
    def _check_category_recursion(self):
        if not self._check_recursion():
            raise ValidationError(_('You cannot create recursive ubication.'))

    @api.model
    def name_create(self, name):
        return self.create({'name': name}).name_get()[0]

    def name_get(self):
        if not self.env.context.get('hierarchical_naming', True):
            return [(record.id, record.name) for record in self]
        return super().name_get()