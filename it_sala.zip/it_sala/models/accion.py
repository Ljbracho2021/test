# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SalaAccion(models.Model):
    _name = 'sala.rol'
    _description = 'Gestión Gobierno - Roles'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre')