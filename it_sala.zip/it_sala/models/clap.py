# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError

class SalaClap(models.Model):
    _name = 'sala.clap'
    _description = 'Gestión Gobierno - Clap'
    _rec_name = 'nombre'

    name = fields.Char(string='Nro.', required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))   
    nombre = fields.Char('Nombre', required = True)
   
    direccion_id = fields.Many2one('sala.direccion', 'Direccioon', required=True)
    territorio_id = fields.Many2one(string='Territorio', related='direccion_id.territorio_id', tracking=True, store=True)

    estado_id = fields.Many2one(string='Estado', related='territorio_id.estado_id', tracking=True, store=True)
    municipio_id = fields.Many2one(string='Municipio', related='territorio_id.municipio_id', tracking=True, store=True)
    parroquia_id = fields.Many2one(string='Parroquia', related='territorio_id.parroquia_id', tracking=True, store=True)
    comuna_id = fields.Many2one(string='Comuna', related='territorio_id.comuna_id', tracking=True, store=True)
    comunidad_id = fields.Many2one(string='Comunidad', related='territorio_id.comunidad_id', tracking=True, store=True)

    jefe_id = fields.Many2one('sala.persona', 'Jefe')
    complete_name = fields.Char('Ubicación', related='territorio_id.complete_name', tracking=True, store=True)
    image = fields.Image(string="Foto", max_width=100, max_height=100, store=True)
    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Favorito'),
    ], required=True, default='0', tracking=True)
    active = fields.Boolean(
        'Active', default=True,
        help="If unchecked, it will allow you to hide the product without removing it.")
    note = fields.Text('Observaciones')

    persona_line_ids = fields.One2many('clap.persona.lines', 'clap_id',
                                            string="Persona Lines")

    calle_line_ids = fields.One2many('clap.calle.lines', 'clap_id',
                                            string="Calles Lines")

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('sala.clap') or _('New')
        res = super(SalaClap, self).create(vals)
        return res

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
        if self.nombre:
            self.nombre = self.nombre.upper()
        
        domain = [('nombre', '=', self.nombre)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.clap'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El nombre para el Clap ya existe ", self.nombre), 
            }}

class ClapPersonaLines(models.Model):
    _name = "clap.persona.lines"
    _description = "clapes / Lideres Lines"

    persona_id = fields.Many2one('sala.persona', 'Persona')
    rol = fields.Selection([
        ('fiscal popular', 'FORMADOR'),
        ('vocero alimentacion', 'VOCERO ALIMENTACION'), 
        ('responsable comunal', 'RESPONSABLE COMUNAL'),
    ], 'Rol', required=True, default='vocero alimentacion', tracking=True)
    
    clap_id = fields.Many2one('sala.clap', string="clap")



class ClapCalleLines(models.Model):
    _name = "clap.calle.lines"
    _description = "clapes / Lideres Calle Lines"

    persona_id = fields.Many2one('sala.persona', 'Persona')
    calle = fields.Char('Calle/Av/Vereda/Manzana', required = True)
    
    clap_id = fields.Many2one('sala.clap', string="clap")