# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaSector(models.Model):
    _name = 'sala.sector'
    _description = 'Gestión Gobierno - Sector'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)