# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaMunicipio(models.Model):
    _name = 'sala.municipio'
    _description = 'Gestión Gobierno - Municipio'
    _rec_name = 'nombre'

    nombre = fields.Char('Municipio', required = True)
    estado_id = fields.Many2one('sala.estado', 'Estado')
    comuna_ids = fields.One2many('sala.comuna', 'municipio_id', string="Comunas")

    comuna_count = fields.Integer(string='Comunas Count', compute='_compute_comuna_count')

    def _compute_comuna_count(self):
        for rec in self:
            comuna_count = self.env['sala.comuna'].search_count([('municipio_id', '=', rec.id)])
            rec.comuna_count = comuna_count

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
        if self.nombre:
            self.nombre = self.nombre.upper()
        
        domain = [('nombre', '=', self.nombre)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.municipio'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El nombre para el Municipio ya existe ", self.nombre), 
            }}

