# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SalaCentro(models.Model):
    _name = 'sala.centro'
    _description = 'Gestión Gobierno - Centro Votacion'
    _rec_name = 'nombre'

    nombre = fields.Char('Nombre', required = True)
    codigo = fields.Char('Código', required = True)


    ubch_id = fields.Many2one('sala.ubch', 'Ubch')

    @api.onchange('codigo')
    def _onchange_codigo(self):
        if not self.codigo:
            return

        domain = [('codigo', '=', self.codigo)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.centro'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El Còdigo del centro de votaciòn ya existe ", self.codigo), 
            }}

    @api.onchange('nombre')
    def _onchange_nombre(self):
         
        if self.nombre:
            self.nombre = self.nombre.upper()
        
        domain = [('nombre', '=', self.nombre)]
        if self.id.origin:
            domain.append(('id', '!=', self.id.origin))
        
        if self.env['sala.centro'].search(domain, limit=1):
            return {'warning': {
                'title': ("Precauciòn:"), 
                'message': ("El nombre para el Centro de votaciòn ya existe ", self.nombre), 
            }}