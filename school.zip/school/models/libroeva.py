# See LICENSE file for full copyright and licensing details.


from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools.translate import _

#--------------------------------------------------------------------------------
# LIBRO / EVALUACION (MASTER)
#--------------------------------------------------------------------------------
class SchoolLibroEvaluacion(models.Model):
    ''' Defining School Information'''

    _name        = 'school.libroeva'
    _description = 'Libro de Evaluacion'
    _order       = "nombre asc"
    _rec_name    = "nombre"
    _inherit     = ['mail.thread', 'mail.activity.mixin']

    #--------------------------------------------------------------------------------
    # VALIDACIONES
    #--------------------------------------------------------------------------------
    @api.constrains('code')
    def _check_code(self):
        for record in self:
            if self.env["school.libroeva"].search(
                [('code', '=', record.code), ('id', '!=', record.id)]):
                raise ValidationError("El código debe ser único")

    #--------------------------------------------------------------------------------
    # CAMPOS
    #--------------------------------------------------------------------------------
    name = fields.Char(string='Libro Nro.', required=True, copy=True, readonly=True, default=lambda self: _('New'))

    school_id    = fields.Many2one('school.campus', 'Campus', required=True, help='School of the following standard')
    cmp_id       = fields.Many2one('res.company', 'Company Nombre', related='school_id.company_id', store=True, help='Company_id of the school')
    nombre       = fields.Char('Nombre', store=True, help='Nombre del libro')
    code         = fields.Char('Código', required=True, help='Code')
    grade_id     = fields.Many2one("grade.master", 'Escala de califiación', help='Related grade')
    is_recupera  = fields.Boolean('¿Acepta recuperación?', default=True, help="Indica la recuperación")
    nro_eva      = fields.Integer("Nro. evaluaciones", store=True, help='Total Evaluaciones')
    porc_peso    = fields.Integer("% Ponderación", default= 0, store=True, help='Total Evaluaciones')
    porc_aprueba = fields.Integer("% de aprobación", default= 0, store=True, help='% aprobación')
    porc_plani   = fields.Integer("% Planificado", default= 0, store=True, help='% aprobación')
    porc_min_eva = fields.Integer("% Mínimo para una evaluación", default= 10, store=True, help='% aprobación')
    porc_max_eva = fields.Integer("% Máximo para una evaluación", default= 30, store=True, help='% aprobación')
    cant_min_eva = fields.Integer("Cantidad mínima de evaluaciones", default= 1, store=True, help='Cantidad Mínima de Evaluaciones')
    cant_max_eva = fields.Integer("Cantidad máxima de evaluaciones", default= 5, store=True, help='Cantidad Máxima de Evaluaciones')
    note         = fields.Text('Observaciones', help='Observaciones')
    state        = fields.Selection([('draft', 'Draft'), 
                                     ('done', 'Done'),
                                     ('terminate', 'Terminate'), 
                                     ('cancel', 'Cancel')], 
                                     'Status', readonly=True, default="draft", tracking=True, help='State of the student registration form')

    evaluacion_ids = fields.One2many('school.libroevas', 'libro_id', 'Evaluaciones', store=True, help='Students which are in this standard')

    @api.model
    def create(self, vals):
          if vals.get('name', _('New')) == _('New'):
              vals['name'] = self.env['ir.sequence'].next_by_code('libroeva.code') or _('New')
          res = super(SchoolLibroEvaluacion, self).create(vals)
          return res


#--------------------------------------------------------------------------------
# LIBRO / EVALUACIONES (LINES)
#--------------------------------------------------------------------------------
class SchoolLibroEvaluaciones(models.Model):
    """Defining grade line."""

    _name        = 'school.libroevas'
    _description = "Libro / Evaluaciones"
    _order       = "nombre asc"

    name         = fields.Char(string='Eva. Nro.', required=True, copy=True, readonly=True, default=lambda self: _('New'))

    nombre       = fields.Char('Nombre', help='Escriba el nombre ')
    code         = fields.Char('Código', required=True, help='Code')
    porc_peso    = fields.Integer("% Ponderación ", store=True, help='% de Ponderación')
        
    porc_aprueba = fields.Integer('% de aprobaciòn', required=True, help='The grade will ends to this marks.')
    is_recupera  = fields.Boolean('¿Acepta recuperación?', default=True, help="Indica la recuperación")
    note         = fields.Text('Observaciones', help='Observaciones')

    libro_id     = fields.Many2one("school.libroeva", 'Libro de evaluación', help='Related libro')

    actividad_ids = fields.One2many('school.libroact', 'evaluacion_id', 'Actividades', store=True, help='Students which are in this standard')


    @api.model
    def create(self, vals):
          if vals.get('name', _('New')) == _('New'):
              vals['name'] = self.env['ir.sequence'].next_by_code('libroevas.code') or _('New')
          res = super(SchoolLibroEvaluaciones, self).create(vals)
          return res

#--------------------------------------------------------------------------------
# LIBRO / ACTIVIDADES (LINES)
#--------------------------------------------------------------------------------
class SchoolLibroActividades(models.Model):
    """Defining grade line."""

    _name        = 'school.libroact'
    _description = "Libro / Actividades"
    _order       = "nombre asc"

    name          = fields.Char(string='Act. Nro.', required=True, copy=True, readonly=True, default=lambda self: _('New'))
    nombre        = fields.Char('Nombre', help='Escriba el Nombre')
    code          = fields.Char('Código', required=True, help='Code')
    tipo_id       = fields.Many2one("school.tipoeva", 'Tipo evaluación', help='Escriba el Tipo de Evaluación')
    porc_peso     = fields.Integer("% Ponderación", store=True, help='Total Evaluaciones')
        
    porc_aprueba  = fields.Integer(' % Aprobaciòn', required=True, help='The grade will ends to this marks.')
    is_recupera   = fields.Boolean('¿Acepta recuperación?', default=True, help="Indica la recuperación")
    note          = fields.Text('Observaciones', help='Observaciones')

    evaluacion_id = fields.Many2one("school.libroevas", 'Libro de evaluaciones', help='Related libro')

    @api.model
    def create(self, vals):
          if vals.get('name', _('New')) == _('New'):
              vals['name'] = self.env['ir.sequence'].next_by_code('libroact.code') or _('New')
          res = super(SchoolLibroActividades, self).create(vals)
          return res
    
 