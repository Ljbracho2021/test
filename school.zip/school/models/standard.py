# See LICENSE file for full copyright and licensing details.

# import time
import calendar
import re

from dateutil.relativedelta import relativedelta
from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.translate import _

EM = (r"[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$")

class SchoolStandard(models.Model):
    '''Defining a standard related to school.'''

    _name = 'school.standard'
    _description = 'School Standards / SECCIONES'
    _rec_name = "standard_id"
    _order = "school_id, code"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    # @api.depends('standard_id', 'school_id', 'division_id', 'medium_id', 'school_id')
    # def _compute_student(self):
    #     '''Compute student of done state'''
    #     student_obj = self.env['school.estudiante']
    #     for rec in self:
    #         rec.student_ids = student_obj.\
    #             search([('standard_id', '=', rec.id),
    #                     ('school_id', '=', rec.school_id.id),
    #                     ('state', '=', 'done')])

    @api.depends('subject_ids')
    def _compute_subject(self):
        '''Method to compute subjects.'''
        for rec in self:
            rec.total_no_subjects = len(rec.subject_ids)

    @api.depends('student_ids')
    def _compute_total_student(self):
        '''Method to compute total student.'''
        for rec in self:
            rec.total_students = len(rec.student_ids)

    @api.depends("capacity", "total_students")
    def _compute_remain_seats(self):
        '''Method to compute remaining seats.'''
        for rec in self:
            rec.remaining_seats = rec.capacity - rec.total_students

    name = fields.Char(string='SEC Nro.', required=True, copy=False, readonly=True, default=lambda self: _('New'))

    code = fields.Char('Código', help='Código de la sección')
    school_id = fields.Many2one('school.campus', 'Campus', required=True, help='School of the following standard')
    standard_id = fields.Many2one('standard.standard', 'Nivel', required=True, help='Standard')
    division_id = fields.Many2one('standard.division', 'Turno', required=True, help='Standard division')
    medium_id = fields.Many2one('standard.medium', 'Modalidad', required=True, help='Medium of the standard')
    subject_id = fields.Many2one('subject.subject', 'Curso', required=True, help='Curso')

    subject_ids = fields.Many2many('subject.subject', 'subject_standards_rel', 'subject_id', 'standard_id', 'Subject', help='Subjects of the standard')
    
    user_id = fields.Many2one('school.teacher', 'Profesor',required=True, help='Teacher of the standard')

    student_ids = fields.One2many('student.inscripcion', 'standard_id', 'Estudiantes Inscritos', store=True, help='Students which are in this standard')
    asistencia_ids = fields.One2many('subject.asistencia', 'standard_id', 'Encuentros', store=True, help='Students which are in this standard')
    evaluacion_ids = fields.One2many('subject.evaluacion', 'standard_id', 'Evaluaciones', store=True, help='Students which are in this standard')

    color = fields.Integer('Color Index', help='Index of color')
    # cmp_id = fields.Many2one('res.company', 'Company Nombre', required=True,store=True, help='Company_id of the school')
    cmp_id = fields.Many2one('res.company', 'Company Nombre', related='school_id.company_id', store=True, help='Company_id of the school')

    # syllabus_ids = fields.One2many('subject.syllabus', 'standard_id',
    #                                'Syllabus',
    #                                help='Syllabus of the following standard')
    total_no_subjects = fields.Integer('Total No of Subject', compute="_compute_subject", help='Total subjects in the standard')
    #name = fields.Char('Nombre', help='Standard name')
    capacity = fields.Integer("Capacidad", help='Standard capacity')
    total_students = fields.Integer("Total Inscritos", compute="_compute_total_student", store=True, help='Total students of the standard')
    remaining_seats = fields.Integer("Cupos Disponibles", compute="_compute_remain_seats", store=True, help='Remaining seats of the standard')
    class_room_id = fields.Many2one('class.room', 'Salón de Clases', required=True, help='Class room of the standard') 
    description = fields.Text('Horario de Clases', help='Horario')

    average_o    = fields.Float('Evaluaciòn Oral', help='Escriba la evaluación Oral', default=0)
    average_e    = fields.Float('Evaluaciòn Escrita', help='Escriba la evaluación Oral', default=0)
    average_t    = fields.Float('Total', help='Escriba la evaluación Oral', default=0)

    state = fields.Selection([('draft', 'Draft'), ('done', 'Done'),('terminate', 'Terminate'), ('cancel', 'Cancel')], 
                             'Status', readonly=True, default="draft", tracking=True, help='State of the student registration form')
    
    @api.model
    def create(self, vals):
          if vals.get('name', _('New')) == _('New'):
              vals['name'] = self.env['ir.sequence'].next_by_code('seccion.code') or _('New')
          res = super(SchoolStandard, self).create(vals)
          return res

    def set_draft(self):
        '''Method to change state to draft'''
        self.state = 'draft'

    def set_done(self):
        '''Method to change state to done'''
        
        #no_subjects = self.get_no_subjects()
        #raise ValidationError(_( "Error : No subjects: " + str(no_subjects) ))
        if self.subject_id:
             self.state = 'done'
             self.generate_encuentros()
             self.generate_evaluaciones()
        else:
             raise ValidationError(_( "Error : No hay Asignaturas en el curso" ))
        
    def set_done_corregir(self):
        '''Method to change state to done'''
        
        if self.subject_id:
             self.asignar_state_corregir()
             self.state = 'done'
             #self.generate_encuentros()
             #self.generate_evaluaciones()
 

    def set_terminate(self):
        '''Set the state to terminate'''
        
        if self.validar_evaluaciones() and self.validar_encuentros():
            self.calcular_promedios(True)
            self.state = 'terminate'
        else:
             raise ValidationError(_( "Error : No se puede cerrar la secciòn. Hay encuentros o evaluaciones pendiantes por realizar" ))

    def set_cancel(self):
        '''Set the state to cancel.'''
        self.state = 'cancel'

    def set_avance(self):
        '''Set the state to done'''
        
        self.calcular_promedios(False)
    

   #-----------------------------------------------------------------------#
   # DESARROLLO PROPIO: SE AGREGO ESTE METODO                              #
   #-----------------------------------------------------------------------#  
    @api.onchange('code')
    def _onchange_code(self):
        if not self.code:
            return
        
        self.code = self.code.upper()

        digito = self.code.isalnum()
        if not digito:
            aux = self.code
            
            return {'warning': {
                'title': ("Mensaje de Error:"), 
                'message': ("Error: El código de la sección debe contener sólo valores alfanumérico..! "), 
            }}
        
        if len(self.code) > 3:
            aux = self.code
            
            return {'warning': {
                'title': ("Mensaje de Error:"), 
                'message': ("Error: El còdigo de la secciòn debe contener hasta 3 caracteres..! "),  
            }}
    #-----------------------------------------------------------------------#    
    def get_no_subjects(self):
        '''Method to compute subjects.'''
        contador = 0
        for rec in self:
             #nombre = rec.standard_id.student_ids[0].student_code
             contador = len(rec.subject_ids)

        return contador
    
    #-----------------------------------------------------------------------#
     
    def get_escala(self):
        '''Method to compute la escala minima.'''

        califica_vals = {'minimo': 0, 'maximo': 0 , 'aprobado': 0 }
  
        escalaObj = self.env['grade.line'].sudo().search([('sequence', '=', '1')], limit=1)

        if escalaObj:
           califica_vals = {'minimo': escalaObj.from_mark, 
                            'maximo': escalaObj.to_mark,
                            'aprobado': escalaObj.pass_mark
                           }
        
        return califica_vals
    
    #-----------------------------------------------------------------------#
    def asignar_state_corregir(self):
        """Generate registro para correccion"""
 
        i      = 1
        no_stu = len(self.student_ids)
        
        while i <= no_stu:

            self.student_ids[i-1].state_eva = 'borrador'
            self.student_ids[i-1].eva_o = 0
            self.student_ids[i-1].eva_e = 0
            self.student_ids[i-1].eva_t = 0
            
            if self.student_ids[i-1].state == 'terminate':
                self.student_ids[i-1].state = 'done'
                
            i = i + 1
    
    #-----------------------------------------------------------------------#   
    def generate_encuentros(self):
        """Generate Encuentros por seccion / Curso."""

        no_encuentros = 0

        asistencia_obj = self.env['subject.asistencia']

        for rec in self:
            
          sta_id = rec.id
          use_id = rec.user_id.id
          sub_id = rec.subject_id.id
          no_encuentros = len(rec.subject_id.encuentro_ids)
          j = 1

          while j <= no_encuentros:
                        
            enc_id = rec.subject_id.encuentro_ids[j-1].id
            aux_desc = rec.subject_id.encuentro_ids[j-1].description

            asistencia_obj.create({
                                   'standard_id' : sta_id,
                                   'subject_id'  : sub_id,
                                   'teacher_id'  : use_id,
                                   'encuentro_id': enc_id,
                                   'description' : aux_desc,
                                 })
            j = j + 1
                     
    #-----------------------------------------------------------------------# 
    # GENERA LAS EVALUACIONES#
    #-----------------------------------------------------------------------#
    def generate_evaluaciones(self):
        """Generate Encuentros por seccion / Curso."""

        no_eva = 0

        evaluacion_obj = self.env['subject.evaluacion']

        for rec in self:
                    
          sta_id = rec.id
          use_id = rec.user_id.id
          sub_id = rec.subject_id.id
          no_eva = len(rec.subject_id.evaluacion_ids)
          j = 1

          while j <= no_eva:
            enc_id = rec.subject_id.evaluacion_ids[j-1].id
            aux_desc = rec.subject_id.evaluacion_ids[j-1].description
            evaluacion_obj.create({
                                   'standard_id'  : sta_id,
                                   'subject_id'   : sub_id,
                                   'teacher_id'   : use_id,
                                   'evaluacion_id': enc_id,
                                   'description'  : aux_desc,
                                  })
            j = j + 1
            
    #-----------------------------------------------------------------------# 
    # VALIDA QUE LAS EVALUACIONES FUERON REALIZADOS                         #
    #-----------------------------------------------------------------------#
    def validar_evaluaciones(self):
         
         auxTerminate = True
         no_eva       = 0
         j            = 1
         no_eva       = len(self.evaluacion_ids)
         
         while j <= no_eva:
            auxState = self.evaluacion_ids[j-1].state

            if auxState != 'terminate':
               auxTerminate = False

            j = j + 1

         return auxTerminate
    
    #-----------------------------------------------------------------------# 
    # VALIDA QUE LOS ENCUANTROS FUERON REALIZADOS                           #
    #-----------------------------------------------------------------------#
    def validar_encuentros(self):
         
         auxTerminate = True
         no_eva       = 0
         j            = 1
         no_eva       = len(self.asistencia_ids)
         
         while j <= no_eva:
            auxState = self.asistencia_ids[j-1].state

            if auxState != 'terminate':
               auxTerminate = False

            j = j + 1

         return auxTerminate
    
    #-----------------------------------------------------------------------# 
    # CALCULA LAS EVALUACIONES QUE FUERON REALIZADAS                        #
    #-----------------------------------------------------------------------#
    def cantidad_evaluacion_cerrada(self):
         
         no_eva       = 0
         j            = 1
         contaDone    = 0
         no_eva       = len(self.evaluacion_ids)
         
         while j <= no_eva:
            auxState = self.evaluacion_ids[j-1].state

            if auxState == 'done':
               contaDone = contaDone + 1

            j = j + 1

         return contaDone

    #-----------------------------------------------------------------------# 
    # CALCULA LOSS PROMEDIOS DE LA SECCION Y DE LOS ESTUDIANTES             #
    #-----------------------------------------------------------------------#
    def calcular_promedios(self,sw):
         
         auxTerminate = True

         acumOral = 0
         acumEsc  = 0
         contaEva = 0

         acumOralStu = 0
         acumEscStu = 0

         tiraStu = ""
         tiraEva = ""
         tiraEvas = ""

         no_stu       = 0
         no_eva       = 0
         i            = 1
         j            = 1
         r            = 1

         calificaVals = self.get_escala()
         no_stu       = len(self.student_ids)
         no_eva       = len(self.evaluacion_ids)
         contaDone    = 0
         contaStu     = 0
         
         while i <= no_stu:

            acumOralStu = 0
            acumEscStu = 0
            auxStu = self.student_ids[i-1].student_id.id
            tiraStu = tiraStu + "Estu :" + str(auxStu) + ";"

            j         = 1
            contaDone = 0

            if self.student_ids[i-1].state != 'cancel':
               contaStu = contaStu + 1

               while j <= no_eva:
                        auxEva = self.evaluacion_ids[j-1].id
                        tiraEva = tiraEva + "Eva :" + str(auxEva) + ";"

                        if self.evaluacion_ids[j-1].state == 'terminate':
                            contaDone = contaDone + 1
                            no_evas = len(self.evaluacion_ids[j-1].evaluacion_ids)
                            r = 1
                            while r <= no_evas:
                                if auxStu == self.evaluacion_ids[j-1].evaluacion_ids[r-1].student_id.id:
                                    
                                    if self.evaluacion_ids[j-1].evaluacion_ids[r-1].is_recupera and self.evaluacion_ids[j-1].evaluacion_ids[r-1].rec_oral > 0:
                                        acumOralStu += self.evaluacion_ids[j-1].evaluacion_ids[r-1].rec_oral
                                    else:
                                        acumOralStu += self.evaluacion_ids[j-1].evaluacion_ids[r-1].eva_oral

                                    if self.evaluacion_ids[j-1].evaluacion_ids[r-1].is_recupera and self.evaluacion_ids[j-1].evaluacion_ids[r-1].rec_esc > 0:
                                        acumEscStu += self.evaluacion_ids[j-1].evaluacion_ids[r-1].rec_esc
                                    else:
                                        acumEscStu += self.evaluacion_ids[j-1].evaluacion_ids[r-1].eva_esc    
                                
                                r = r + 1

                        j = j + 1
            
            if contaDone > 0:
               self.student_ids[i-1].eva_o = acumOralStu / contaDone
               self.student_ids[i-1].eva_e = acumEscStu / contaDone
               self.student_ids[i-1].eva_t = ((acumOralStu / contaDone) + (acumEscStu / contaDone))/2

               if self.student_ids[i-1].state != 'cancel':
                    if self.student_ids[i-1].eva_t >= calificaVals['aprobado']:
                            self.student_ids[i-1].state_eva = 'aprobado'
                    else:
                            self.student_ids[i-1].state_eva = 'aplazado'
                
                
                    if sw:
                        self.student_ids[i-1].state = 'terminate'
                    else:
                        self.student_ids[i-1].state = 'done'

               acumOral+= (acumOralStu / contaDone)
               acumEsc+= (acumEscStu / contaDone)

            else:
                self.student_ids[i-1].eva_o = 0
                self.student_ids[i-1].eva_e = 0
                self.student_ids[i-1].eva_t = 0

            i = i + 1

         if contaStu > 0:
             self.average_o = (acumOral / contaStu)
             self.average_e = (acumEsc / contaStu)
             self.average_t = (self.average_o + self.average_e ) / 2

         return auxTerminate
   #-----------------------------------------------------------------------# 

    @api.onchange('standard_id', 'division_id')
    def onchange_combine(self):
        '''Onchange to assign name respective of it's standard and division'''
        #self.name = str(self.standard_id.name ) + '-' + str(self.division_id.name)

    #@api.constrains('standard_id', 'division_id')
    #def check_standard_unique(self):
    #    """Method to check unique standard."""
    #    if self.env['school.standard'].search([
    #                            ('standard_id', '=', self.standard_id.id),
    #                            ('division_id', '=', self.division_id.id),
    #                            ('school_id', '=', self.school_id.id),
    #                            ('id', 'not in', self.ids)]):
    #        raise ValidationError(_("Division and class should be unique!"))

    @api.constrains('standard_id', 'division_id')
    def check_standard_unique(self):
        """Method to check unique standard."""
        if self.env['school.standard'].search([
                                
                                ('code', '=', self.code),
                                ('school_id', '=', self.school_id.id),
                                ('id', 'not in', self.ids)]):
            raise ValidationError(_("El còdigo de la secciòn debe ser ùnico en el campus!"))
  
    # def unlink(self):
    #     """Method to check unique standard."""
    #     for rec in self:
    #         if rec.student_ids or rec.subject_ids or rec.syllabus_ids:
    #             raise ValidationError(_(
    # "You cannot delete as it has reference with student, subject or syllabus!"))
    #     return super(SchoolStandard, self).unlink()

    @api.constrains('capacity')
    def check_seats(self):
        """Method to check seats."""
        if self.capacity <= 0:
            raise ValidationError(_("Total seats should be greater than 0!"))

    def name_get(self):
        '''Method to display standard and division'''
        #return [(rec.id, rec.standard_id.name + '-' + '[' + rec.division_id.name + ']' + '[' + rec.code + ']') for rec in self]
        return [(rec.id, rec.school_id.code + '-' + '[' + rec.division_id.name + ']' + '[' + rec.name + ']' + '[' + rec.code + ']') for rec in self]

