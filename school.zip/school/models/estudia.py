# See LICENSE file for full copyright and licensing details.

import base64

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.modules import get_module_resource
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.translate import _

# from lxml import etree
# added import statement in try-except because when server runs on
# windows operating system issue arise because this library is not in Windows.
try:
    from odoo.tools import image_colorize
except:
    image_colorize = False

class SchoolEstudiante(models.Model):
    ''' Defining School Information'''

    _name = 'school.estudiante'
    _description = 'Informaciòn del estudiante'


    @api.depends('date_of_birth')
    def _compute_student_age(self):
        '''Method to calculate student age'''
        current_dt = fields.Date.today()
        for rec in self:
            rec.age = 0
            if rec.date_of_birth and rec.date_of_birth < current_dt:
                start = rec.date_of_birth
                age_calc = ((current_dt - start).days / 365)
                # Age should be greater than 0
                if age_calc > 0.0:
                    rec.age = age_calc

    @api.model
    def _default_image(self):
        '''Method to get default Image'''
        image_path = get_module_resource('hr', 'static/src/img',
                                         'default_image.png')
        return base64.b64encode(open(image_path, 'rb').read())

    @api.constrains('student_ci')
    def _check_code(self):
        for record in self:
            if self.env["school.estudiante"].search(
                [('student_ci', '=', record.student_ci), ('id', '!=', record.id)]):
                raise ValidationError("Student Código must be Unique")
            
    user_id       = fields.Many2one('res.users', 'User ID', ondelete="cascade", required=True, delegate=True, help='Select related user of the student')
    student_ci    = fields.Char('Student CI', help='Enter student ci')
    pid           = fields.Char('Estudiante ID', required=True, default=lambda self: _('New'), help='Personal IDentification Number')
    reg_code      = fields.Char('Registration Code', help='Student Registration Code')
    school_id     = fields.Many2one('school.campus', 'Campus', states={'done': [('readonly', True)]}, help='Select school', tracking=True)
    student_code = fields.Char('Student Code', help='Enter student code')
    middle = fields.Char('Middle Nombre', states={'done': [('readonly', True)]}, help='Enter student middle name')
    admission_date = fields.Date('Fecha de Admisiòn', default=fields.Date.today(), help='Enter student admission date')
    photo         = fields.Binary('Photo', default=_default_image, help='Attach student photo')
    date_of_birth = fields.Date('BirthDate', states={'done': [('readonly', True)]}, help='Enter student date of birth')
    age           = fields.Integer(compute='_compute_student_age', string='Age', readonly=True, help='Enter student age')
    last          = fields.Char('Surname', states={'done': [('readonly', True)]}, help='Enter student last name')
    gender        = fields.Selection([('male', 'Male'), ('female', 'Female')], 'Sexo', states={'done': [('readonly', True)]}, help='Select student gender')
    active        = fields.Boolean(default=True, help='Activate/Deactivate student record', tracking=True)
    state         = fields.Selection([('draft', 'Draft'), ('done', 'Done'),
                                      ('terminate', 'Terminate'), ('cancel', 'Cancel'),
                                      ('alumni', 'Alumni')], 
                                      'Status', readonly=True, default="draft", tracking=True, help='State of the student registration form')
    maritual_status = fields.Selection([('unmarried', 'Unmarried'),
        ('married', 'Married')], 'Marital Status',
        states={'done': [('readonly', True)]},
        help='Select student maritual status')
    contact_phone = fields.Char('Phone no.', help='Enter student phone no.')
    contact_mobile = fields.Char('Mobile no', help='Enter student mobile no.')
    terminate_reason = fields.Text('Reason', help='Enter student terminate reason', tracking=True)
    roll_no = fields.Integer('No.', readonly=True, help='Enter student roll no.')
    inscripcion_ids = fields.One2many('student.inscripcion', 'student_id',
                                  'Student In Class',
                                  store=True,
                                  help='Students which are in this standard'
                                  )

    @api.model
    def create(self, vals):
        '''Method to create user when student is created'''
        if vals.get('pid', _('New')) == _('New'):
            vals['pid'] = self.env['ir.sequence'
                                   ].next_by_code('student.student'
                                                  ) or _('New')
            
        if vals.get('pid', False):
            vals['login'] = vals['pid']
            vals['password'] = vals['pid']
        else:
            raise UserError(_(
                    "Error! PID not valid so record will not be saved."))
        
        if vals.get('company_id', False):
            company_vals = {'company_ids': [(4, vals.get('company_id'))]}
            vals.update(company_vals)
    
        res = super(SchoolEstudiante, self).create(vals)

        return res