# See LICENSE file for full copyright and licensing details.

import base64

from odoo import _, api, fields, models
from odoo.exceptions import UserError, ValidationError

class StudentInscripcion(models.Model):
    '''Defining a student inscripcion.'''

    _name = 'student.inscripcion'
    _description = 'Student Inscripcion'

    @api.model
    def check_current_year(self):
        '''Method to get default value of logged in Student'''
        res = self.env['academic.year'].search([('current', '=', True)])
        if not res:
            raise ValidationError(_("There is no current Academic Year defined! Please contact Administator!"))
        return res.id

    student_id = fields.Many2one('student.student', 'Estudiante', help='Select student', required=True)
    
    standard_id = fields.Many2one('school.standard', 'Incripción en la Sección', help='Select student standard', required=True, tracking=True)

    year = fields.Many2one('academic.year', 'Lapso', readonly=True, default=check_current_year, help='Seleccione Lapso Académico', tracking=True)

    school_id = fields.Many2one('school.school', 'Sede', help='Select school', required=True, tracking=True)

    date_inscripcion = fields.Date(string="Fecha", required=True, default=fields.Date.today)

    move_id = fields.Many2one("account.move", "Factura Asociada", required=True, help="Link to the automatically generated Journal Items.")
    
    state = fields.Selection([('draft', 'Draft'), 
                              ('done', 'Done'),
                              ('terminate', 'Terminate'), 
                              ('cancel', 'Cancel'),
                             ], 'Status', readonly=True, default="draft", tracking=True, help='State of the student registration form')
    
    def set_to_draft(self):
        '''Method to change state to draft'''
        self.state = 'draft'

    def set_done(self):
        '''Method to change state to done'''
        self.state = 'done'

    def admission_draft(self):
        '''Set the state to draft'''
        self.state = 'draft'

    def set_terminate(self):
        '''Set the state to terminate'''
        self.state = 'terminate'

    def cancel_admission(self):
        '''Set the state to cancel.'''
        self.state = 'cancel'

    def admission_done(self):
        '''Method to confirm admission'''

        studentObj = self.env['student.student'].sudo().search([('id', '=', self.student_id.id)], limit=1)

        if studentObj:
            
            studentObj.school_id = self.school_id
            studentObj.standard_id = self.standard_id

            school_standard_obj = studentObj.env['school.standard']
            ir_sequence = studentObj.env['ir.sequence']
            student_group = studentObj.env.ref('school.group_school_student')
            emp_group = studentObj.env.ref('base.group_user')
            
            for rec in studentObj:
                if not rec.standard_id:
                    raise ValidationError(_("Please select class!"))
                if rec.standard_id.remaining_seats <= 0:
                    raise ValidationError(_('Seats of class %s are full'
                                            ) % rec.standard_id.standard_id.name)
                domain = [('school_id', '=', rec.school_id.id)]
                # Checks the standard if not defined raise error
                if not school_standard_obj.search(domain):
                    raise UserError(_(
                            "Warning! The standard is not defined in school!"))
                # Assign group to student
                rec.user_id.write({'groups_id': [(6, 0,
                                    [emp_group.id, student_group.id])]})
                # Assign roll no to student
                number = 1
                for rec_std in rec.search(domain):
                    rec_std.roll_no = number
                    number += 1
                # Assign registration code to student
                reg_code = ir_sequence.next_by_code('student.registration')
                registation_code = (str(rec.school_id.state_id.name) + str('/') +
                                    str(rec.school_id.city) + str('/') +
                                    str(rec.school_id.name) + str('/') +
                                    str(reg_code))
                stu_code = ir_sequence.next_by_code('student.code')
                student_code = (str(rec.school_id.code) + str('/') +
                                str(rec.year.code) + str('/') +
                                str(stu_code))
                rec.write({'state': 'done',
                        'admission_date': fields.Date.today(),
                        'student_code': student_code,
                        'reg_code': registation_code})
                template = studentObj.env['mail.template'].sudo().search([
                    ('name', 'ilike', 'Admission Confirmation')], limit=1)
                if template:
                    for user in rec.parent_id:
                        subject = _("About Admission Confirmation")
                        if user.email:
                            body = """
                            <div>
                                <p>Dear """ + str(user.display_name) + """,
                                <br/><br/>
                                Admission of """+str(rec.display_name)+""" has been confirmed in """+str(rec.school_id.name)+""".
                                <br></br>
                                Thank You.
                            </div>
                            """
                            template.send_mail(rec.id, email_values={
                                'email_from': studentObj.env.user.email or '',
                                'email_to': user.email,
                                'subject': subject,
                                'body_html': body,
                                }, force_send=True)
                self.state = 'done'
                return True
    