# See LICENSE file for full copyright and licensing details.


from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.translate import _

class StudentInscripcion(models.Model):
    '''Defining a student inscripcion.'''

    _name = 'student.inscripcion'
    _description = 'Student Inscripcion'
    _order = "inscription_date desc,name desc"

    @api.constrains('student_id')
    def _check_code(self):
         for record in self:
             domain = [('id', '!=', record.id), ('student_id', '=' , record.student_id.id), ('standard_id', '=' , record.standard_id.id)]
             if self.env["student.inscripcion"].search(domain):
                raise ValidationError("Error: El estudiante ya està inscrito en la SECCIÒN..!")

    name = fields.Char(string='RI Nro.', required=True, copy=False, readonly=True, default=lambda self: _('New'))
    student_id       = fields.Many2one('school.estudiante', 'Estudiante', help='Select student', required=True)
    standard_id      = fields.Many2one('school.standard', 'Sección', help='Select student standard', required=True, tracking=True)
    school_id        = fields.Many2one('school.campus', 'Campus', help='Select Campus', required=True, tracking=True)
    inscription_date = fields.Date(string="Fecha", required=True, default=fields.Date.today)
    move_id          = fields.Many2one("account.move", "Factura Asociada", required=True, help="Link to the automatically generated Journal Items.")
    state            = fields.Selection([('draft', 'Draft'), 
                                         ('done', 'Done'),
                                         ('terminate', 'Terminate'), 
                                         ('cancel', 'Cancel'),
                                        ], 'Status', readonly=True, default="draft", tracking=True, help='State of the student registration form')

    def set_to_draft(self):
        '''Method to change state to draft'''
        self.state = 'draft'

    def set_done(self):
        '''Method to change state to done'''
        self.state = 'done'

    def admission_draft(self):
        '''Set the state to draft'''
        self.state = 'draft'

    def set_terminate(self):
        '''Set the state to terminate'''
        self.state = 'terminate'

    def cancel_admission(self):
        '''Set the state to cancel.'''
        self.state = 'cancel'

    def admission_done(self):
        '''Method to confirm admission'''
        self.state = 'done'
 
        
        if self.student_id.state == 'draft':
           self.student_id.state ='done'
        

    @api.model
    def create(self, vals):
         if vals.get('name', _('New')) == _('New'):
             vals['name'] = self.env['ir.sequence'].next_by_code('inscripcion.code') or _('New')
         res = super(StudentInscripcion, self).create(vals)
         return res


    