# See LICENSE file for full copyright and licensing details.



from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT
from odoo.tools.translate import _


class StudentInscripcion(models.Model):
    '''Defining a student inscripcion.'''

    _name = 'student.inscripcion'
    _description = 'Student Inscripcion'
    _order = "inscription_date desc,name desc"
    _inherit = ['mail.thread', 'mail.activity.mixin']
 
    @api.constrains('student_id')
    def _check_code(self):
         for record in self:
             domain = [('id', '!=', record.id), ('student_id', '=' , record.student_id.id), ('standard_id', '=' , record.standard_id.id)]
             if self.env["student.inscripcion"].search(domain):
                raise ValidationError("Error: El estudiante ya està inscrito en la SECCIÒN..!")
             
    @api.depends('state')
    def _compute_state(self):
        '''Method to compute total student.'''
        for rec in self:
            rec.state_aux = self.get_estado(rec.state)

    name = fields.Char(string='RI Nro.', required=True, copy=False, readonly=True, default=lambda self: _('New'))
    #student_id      = fields.Many2one('school.estudiante', 'Estudiante', help='Select student', required=True)
    student_id       = fields.Many2one('student.student', 'Estudiante', help='Select student', required=True)
    standard_id      = fields.Many2one('school.standard', 'Sección', help='Select student standard', required=True, tracking=True)
    school_id        = fields.Many2one('school.campus', 'Campus', help='Select Campus', required=True, tracking=True)
    subject_id       = fields.Many2one('subject.subject', 'Curso', related='standard_id.subject_id', required=True, help='Curso')
    inscription_date = fields.Date(string="Fecha", required=True, default=fields.Date.today)
    move_id          = fields.Many2one("account.move", "Factura Asociada", required=True, help="Link to the automatically generated Journal Items.")
    partner_id       = fields.Many2one('res.partner', 'Contacto',  related='move_id.partner_id', help='Select Contacs', required=True)

    eva_o = fields.Float('Evaluación Oral', help='Escriba la evaluación Oral', default=0)
    eva_e = fields.Float('Evaluación Escrita', help='Escriba la evaluación Escrita', default=0)
    eva_t = fields.Float('Promedio', readonly=True, help='Evaluación Promedio', default=0)
    
    state            = fields.Selection([('draft', 'Draft'), 
                                         ('done', 'Done'),
                                         ('terminate', 'Terminate'), 
                                         ('cancel', 'Cancel'),
                                        ], 'Registro Inscripciòn', readonly=True, default="draft", tracking=True, help='State of the student registration form')
    
    state_aux        = fields.Selection([('por iniciar', 'Por iniciar'), 
                                         ('iniciado', 'Iniciado'),
                                         ('culminado', 'Culminado'), 
                                         ('retirado', 'Retirado'),
                                        ], 'Registro Inscripciòn', readonly=True, default="por iniciar", tracking=True, help='State of the student registration form'
                                        , compute="_compute_state")
    

    
    state_eva       = fields.Selection([('borrador', 'Borrador'), 
                                        ('aprobado', 'Aprobado'),
                                        ('aplazado', 'Aplazado'), 
                                        ('inasistente', 'Inasistente'),
                                       ], 'Calificaciòn', readonly=True, default="borrador", help='State of the student registration form')
    
    name = fields.Char(string='RI Nro.', required=True, copy=False, readonly=True, default=lambda self: _('New'))
    
    description = fields.Text('Observaciones', help='Observaciones')

    def set_to_draft(self):
        '''Method to change state to draft'''
        self.state = 'draft'

    def set_done(self):
        '''Method to change state to done'''
        self.state = 'done'

    def admission_draft(self):
        '''Set the state to draft'''
        self.state = 'draft'

    def set_terminate(self):
        '''Set the state to terminate'''
        self.state = 'terminate'

    def cancel_admission(self):
        '''Set the state to cancel.'''
        self.state = 'cancel'

    def admission_done(self):
        '''Method to confirm admission'''
        self.state = 'done'
         
        if self.student_id.state == 'draft':
           self.generar_eva()
        #    self.student_id.state ='done'
        #    self.student_id.standard_id = self.standard_id

#-----------------------------------------------------------------------#
    def get_estado(self , sta):
        '''Method to compute la escala minima.'''

        if sta == 'draft':
           return 'por iniciar'
        elif sta == 'done':
           return 'iniciado' 
        elif sta == 'terminate':
           return 'culminado'
        elif sta == 'cancel':
           return 'retirado'
        else:
            return sta
        
        return sta           
#-----------------------------------------------------------------------#

    @api.model
    def create(self, vals):
         if vals.get('name', _('New')) == _('New'):
             vals['name'] = self.env['ir.sequence'].next_by_code('inscripcion.code') or _('New')
         res = super(StudentInscripcion, self).create(vals)
         return res
    
    def generar_eva(self):
         for record in self:
             
             domain          = [('standard_id', '=' , record.standard_id.id)]
             evaluacionObj   = self.env["subject.evaluacion"].search(domain)
             evaluacionesObj = self.env['subject.evaluaciones']

             if evaluacionObj:
                #----------------------------------------------------------------------------#
                #  CICLO DE LAS EVALUACIONES DE LA SECCION                                   #
                #----------------------------------------------------------------------------#
                for eva in evaluacionObj:
                    #----------------------------------------------------------------------------#
                    #  GENERA REGISTRO DE EVALUACION SI EL STATE ES DIFERENTE DE DRAFT           #
                    #----------------------------------------------------------------------------#
                    if eva.state != 'draft':
                       evaluacionesObj.create({
                           
                            'inscripcion_id': self.id,
                            'evaluacion_id': eva.id,
                            'student_id': self.student_id.id,

                            'eva_oral': 0,
                            'eva_esc': 0,
                            'rec_oral': 0,
                            'rec_esc': 0,
                            'is_recupera': False,
                            'eva_total': 0,
                            'description': " ",
                            
                        })
                    #raise ValidationError("Encontro las evaluaciones de la seccion: ..!" + "Nombre:" + str(eva.evaluacion_id.name) + "State:" + str(eva.state))

 #-----------------------------------------------------------------------#    
    def name_get(self):
        #       '''Method to display standard and division'''
        return [(rec.id, rec.name + '-' + '[' + rec.standard_id.name + '-' + rec.standard_id.code + '-' + rec.subject_id.nombre + ']') for rec in self]



    