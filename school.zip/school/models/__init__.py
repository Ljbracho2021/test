# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to School Management System
# ----------------------------------------------------------
#from . import res_partner
from . import evaluacion
from . import school
from . import standard
from . import campus
from . import subject

from . import asistencia
from . import student
from . import estudiante
from . import estudia
from . import teacher
from . import parent
from . import res_users
from . import inscripcion
from . import curso


