# -*- coding: utf-8 -*-
{
    'name': "ITSoluciones Web Reports",
    'summary': "Reports with custom header and footer",
    'description': """

Reports sample with custom header and footer
""",
    'author': "itsolucionesweb Software",
    'category': 'Uncategorized',
    'version': '15.0.22.04.20',
    'website': "https://www.itesolucionesweb.com",
    'depends': ['base',
                'it_sala'],
    'license': 'AGPL-3',
    'data': [
        'report/report.xml',
        'report/reportuni.xml',
        'report/reportco.xml',  
        #'report/reportcc.xml',
        #'report/reporton.xml',       
        'security/ir.model.access.csv',
        'wizard/wizard.xml',
        'wizard/wizarduni.xml',
        'wizard/wizardco.xml',
        #'wizard/wizardcc.xml',
        #'wizard/wizardon.xml',
    ],
    'images': [
        'static/description/icon.jpg'
    ],
}