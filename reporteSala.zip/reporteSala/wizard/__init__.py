# -*- coding: utf-8 -*-

from . import wizard
from . import wizarduni
from . import wizardco
from . import wizardcc
#from . import wizardon