# -*- coding: utf-8 -*-

from . import impresora

from . import ReportData
from . import S1PrinterData
from . import S2PrinterData
from . import S3PrinterData
from . import S4PrinterData
from . import S5PrinterData
from . import S6PrinterData
from . import S7PrinterData
from . import S8EPrinterData
from . import S8PPrinterData
from . import AcumuladosX
from . import Tfhka
from . import Util