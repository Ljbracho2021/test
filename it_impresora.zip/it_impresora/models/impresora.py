# -*- coding: utf-8 -*-
 
from email.policy import default
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

from functools import reduce

import sys
import Tfhka
import serial
import os
import time

import xmlrpc.client


import operator
import time
import datetime

import glob


#-------------------------------------------------------------------
# CLASS: IMPRESORA
#-------------------------------------------------------------------
class ImpresoraImpresora(models.Model):
    _name        = 'impresora.impresora'
    _description = 'Gestión impresora - impresora'
    _rec_name    = 'nombre'
 
    name = fields.Char(string='Nro.', required=True, copy=False, readonly=True,
                       default=lambda self: _('New'))  
 
    nombre = fields.Char('Nombre', required = True)
    
    # puerto = fields.Selection([('com1', 'COM1'),
    #                            ('com2', 'COM2'),
    #                            ('com3', 'COM3')], default='COM3', string="Puerto", required=True)

    puerto = fields.Char(string="Puerto", required = True, default='COM3')
 
    image = fields.Image(max_width=100, max_height=100, store=True)
   
    priority = fields.Selection([
        ('0', 'Normal'),
        ('1', 'Favorito'),
    ], required=True, default='0')
 
    active = fields.Boolean(
        'Active', default=True,
        help="If unchecked, it will allow you to hide the product without removing it.")
    note = fields.Text(string="Observaciones")
 
    state = fields.Selection([('desconectada', 'DESCONECTADA'),
                              ('conectada', 'CONECTADA'),
                              ('cancelada', 'CANCELADA')], default='desconectada', string="Status")    

    printer = Tfhka.Tfhka()

    def action_conectar(self):
        self.state = ''
        
        if self.printer.OpenFpctrl(self.puerto):
           self.state = 'conectada'
           #raise ValidationError(_("MENSAJE: " + str(self.printer.ser.name)))
        else:
            self.state = 'desconectada'
            raise ValidationError(_("MENSAJE: " + self.printer.envio))

    def action_desconectar(self):
        self.state = ''
               
        if not self.printer.CloseFpctrl():
           self.state = 'desconectada'
           # raise ValidationError(_("Error: " + str(self.printer.ser)))

        else:
           self.state = 'conectada'
 
    def action_reporteX(self):
       if not self.printer.CloseFpctrl():
        if self.printer.OpenFpctrl(self.puerto):
           self.trama = self.printer.GetXReport()
           raise ValidationError(_("Imprimio Reporte X :" + self.trama))

    def action_estado(self):
        if self.printer.ser.isOpen():
           self.trama = self.printer.GetS1PrinterData()
        
       
    

    

