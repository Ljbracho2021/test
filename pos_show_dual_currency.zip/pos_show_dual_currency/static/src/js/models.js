odoo.define('pos_show_dual_currency.models_Paymentline', function(require) {
    "use strict";

    const models = require('point_of_sale.models');

    /*models.load_fields('pos.payment.method','is_dollar_payment');

    
    let PaymentlineSuper = models.Paymentline.prototype;
    models.Paymentline = models.Paymentline.extend({
        initialize: function(attributes, options) {
            // Compatibility with pos_cache module
            PaymentlineSuper.initialize.apply(this, arguments);
        },

        // set_amount: function(value){
        //     *//* CODE *//*
        //     PaymentlineSuper.set_amount.apply(this, [value]);
        // },


        
    });*/

});