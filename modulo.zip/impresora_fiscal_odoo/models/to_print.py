# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
import logging

from odoo import models, fields, api
from odoo.modules.module import get_module_resource
import json
import base64
import requests
import datetime
import time

logger = logging.getLogger(__name__)


def _calculate_tax(amount):
    iva = 13.7931034482759
    resp = amount - (amount * iva / 100)
    return resp


class ToPrintFiscal(models.Model):
    _name = "stzr.printer.fiscal.to.print"
    _description = "Modelo que permite imprimir por la impresora fiscal"

    def convert_amount(self, company_id, c_from, amount, c_to):
        company = self.env['res.company'].search([('id', '=', company_id)])
        currency_from = self.env['res.currency'].search([('name', '=', c_from)])
        currency_to = self.env['res.currency'].search([('name', '=', c_to)])
        return currency_to._compute(currency_from, currency_to, amount)

    def recuest_response(self, url, payload, headers, method='GET'):
        try:
            if method == 'GET':
                response = requests.get(url + payload)
            if method == 'POST':
                response = requests.post(url, data=json.dumps(payload), headers=headers)

            logger.info("Info Exit recuest_response: %s:%s" % (response, response.text))
            return response
        except Exception as exc:
            return {
                'error': True,
                'sms': exc
            }

    def pos_print_fiscal(self, sale):
        # self.petropago_success('false')
        # sale = self.ids
        try:
            resp = ''
            if sale:
                type_invoice = sale[0].get('type_invoice') if sale[0].get('type_invoice') else 'factura_normal'

                if not self.search(
                        [('n_order', '=', sale[0].get('n_order')), ('type_invoice', '=', type_invoice)]
                ) or type_invoice in ['reporte_x', 'reporte_z']:

                    for pay in sale[0]['payment_methods_json']:
                        pay['amount'] = self.convert_amount(
                            sale[0]['company_id'],
                            sale[0]['currency_name'],
                            # _calculate_tax(pay['amount']),
                            pay['amount'],
                            'VEF'
                        )

                    for s in sale:
                        # type_invoice = s.get('type_invoice') if s.get('type_invoice') else 'factura_normal'
                        #
                        # if not self.search(
                        #         [('n_order', '=', s.get('n_order')), ('type_invoice', '=', type_invoice)]
                        # ) or type_invoice in ['reporte_x', 'reporte_z']:
                        client = self.env['res.partner'].search([('id', '=', s.get('client_id'))])
                        s['client_name'] = client['name']
                        # s['client_rifCi'] = client['vat'] or ''
                        s['client_rifCi'] = client['cedula'] or ''
                        s['client_address'] = '%s %s %s' % (
                            client['street'] or '',
                            client['zip'] or '',
                            client['city'] or 'Caracas'
                        )
                        # s['client_address'] = '%s' % (client['city'] or 'Caracas')

                        if s['currency_name'] not in ['VEF']:
                            s['price'] = self.convert_amount(
                                s['company_id'],
                                s['currency_name'],
                                _calculate_tax(s['price']),
                                'VEF'
                            )

                            # for pay in s['payment_methods_json']:
                            #     pay['amount'] = self.convert_amount(
                            #         s['company_id'],
                            #         s['currency_name'],
                            #         # _calculate_tax(pay['amount']),
                            #         pay['amount'],
                            #         'VEF'
                            #     )

                        resp = self.env['stzr.printer.fiscal.to.print'].sudo().create(s)

                    logger.info('OK pos_print_fiscal [ %s: Respuesta %s ]' % (s, resp))
                return {
                    'error': False,
                    'sms': 'Imprimiento...'
                }
        except Exception as exc:
            logger.error("Error pos_print_fiscal: %s" % exc)
            return {
                'error': True,
                'sms': exc
            }

    def check_pay(self, sl):
        # if slp:
        #     for i in range(0, 18):
        #         print('petro pago esperando... ', i)
        #         res = self.petropago_success(slp)
        #         if res.get('error'):
        #             return {
        #                 'error': True,
        #                 'sms': res.get('sms')
        #             }
        #         if res.get('sms') == 2:
        #             break
        #         time.sleep(10)
        #
        #     if not res.get('sms') == 2:
        #         return {
        #             'error': True,
        #             'sms': 'Luego de mucho esperar no se encontro el pago en Petros. Status: %s' % res.get('sms')
        #         }
        return self.pos_print_fiscal(sl)  # Activar si se usa una impresora fiscal
        # return {  #Desactivar si se usa una impresora fiscal
        #     'error': False,
        #     'sms': 'Imprimiento...'
        # }

    n_order = fields.Char(string='N de Orden')
    product_name = fields.Char(string='Nombre del Producto')
    price = fields.Char(string='Precio')
    price_extra = fields.Char(string='Precio Extra')
    currency_name = fields.Char(string='Moneda')
    quantity = fields.Char(string='Cantidad')
    employee_name = fields.Char(string='Nombre del Empleado')
    pos_session_name = fields.Char(string='# del Punto de Venta')
    client_name = fields.Char(string='Nombre del cliente')
    client_rifCi = fields.Char(string='Rif/CI del cliente')
    client_address = fields.Char(string='Dirección del cliente')
    client_id = fields.Char(string='ID del cliente')
    taxes_id = fields.Char(string='ID del(os) immpuesto(s)')
    port_printer_name = fields.Char(string='Nombre del puerto')
    company_id = fields.Char()
    printed_invoice = fields.Selection([('no_printed', 'No'),
                                        ('printed', 'Si')],
                                       string='Factura Fiscal Impresa',
                                       default='no_printed')
    type_invoice = fields.Selection([('factura_normal', 'Factura Normal'),
                                     ('reporte_x', 'Reporte X'),
                                     ('reporte_z', 'Reporte Z'),
                                     ('nota_credito', 'Nota de Crédito'),
                                     ('nota_debito', 'Nota de Débito'),
                                     ],
                                    string='Tipo de fatura',
                                    default='factura_normal')
    invoice_id = fields.Integer(string='Correlativo de la factura a devolver')
    invoice_date = fields.Char(string='facha de la factura a devolver')
    printer_serial = fields.Char(string='Serial de la impresora donde se imprimió la factura a devolver')
    payment_methods_json = fields.Char(string='JSON que contiene todos los metodos de pago')
