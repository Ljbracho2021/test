import logging
import re
from odoo import fields, models, api
from odoo.exceptions import ValidationError

logger = logging.getLogger(__name__)

_RETURNS = {
    'error': False,
    'sms': '',
    'data': ''
}
_RETURN_ERRORS = {
    'error': True,
    'sms': '',
    'data': ''
}

SMS = {
    '100': '\n %s MODELO: %s -- %s ==> %s',
    '101': '\n OK SE MANDO A LA IMPRESORA LA NOTA DE CRÉDITO',
    '001': 'No tiene una impresion de factura normal registrada, por tanto, no puede generar Nota de Crédito',

}


def _begin(r):
    logger.info("\n info MODELO: %s -- %s ==> %s | SELF: %s" % (
        'PosMakePaymentReturnModel', '', r, ''
    ))


def _return_ok(o, r):
    logger.info(SMS['100'] % ('info', 'PosMakePaymentReturnModel', o, r))
    return r


def _return_err(o, r):
    logger.error(SMS['100'] % ('Error', 'PosMakePaymentReturnModel', o, r))
    return r


def _ok(data, sms=None):
    RETURNS = _RETURNS.copy()
    RETURNS.update({
        'sms': sms or '',
        'data': data
    })
    _return_ok(RETURNS, RETURNS['sms'])
    return RETURNS


def _error(obj, sms):
    RETURN_ERR = _RETURN_ERRORS.copy()
    RETURN_ERR.update({'sms': sms})
    r = _return_err(obj, RETURN_ERR['sms'])
    raise ValidationError(r)


# def _catch_exception(exc):
#     RETURN_ERRORS = _RETURN_ERRORS.copy()
#     text = exc
#     # if type(exc.args[0]) == str:
#     #     text = exc.args[0]
#     # elif ('[WinError 10060]' or 'Failed to establish a new connection') in exc.args[0].reason.args[0]:
#     #     text = 'Falla de conexión a Internet, intente nuevamente o cambie método de pago'
#     logger.error("Excepción %s: %s (%s)" % ('', ('' if text == exc else text), exc))
#     RETURN_ERRORS.update({'sms': text})
#     return RETURN_ERRORS


class PosMakePaymentReturnModel(models.TransientModel):
    _inherit = "pos.make.payment"

    def check(self):
        self._send_to_print()
        return super(PosMakePaymentReturnModel, self).check()

    def _send_to_print(self):
        try:
            _begin(self)

            current_order_id = self.env.context.get('active_id')
            current_order = self.env['pos.order'].sudo().browse(current_order_id)

            # if not current_order.vals_print_fiscal.secuencia:
            #     return _ok('', SMS['001'])
            if current_order.fiscal_position_id:
                return True
            to_print = self.env['stzr.printer.fiscal.to.print'].sudo()
            sale_list = []
            for order_line in current_order.lines:
                sale_list.append({
                    'n_order': str(''.join(re.findall("[0-9-]", current_order.pos_reference))),
                    'product_name': order_line.display_name,
                    'price': order_line.price_unit,
                    # 'price_extra': "x.price_extra",
                    'currency_name': "USD",
                    'quantity': str(int(abs(order_line.qty))),
                    'employee_name': current_order.create_uid.name or '',
                    'pos_session_name': self.config_id.current_session_id.display_name,
                    'client_id': str(current_order.partner_id.id),
                    'taxes_id': [tax.description for tax in order_line.tax_ids if 'EXENTO' in tax.description],
                    'port_printer_name': 'COM' + str(self.config_id.port_printer),
                    'company_id': str(current_order.company_id.id),
                    'type_invoice': 'nota_credito',
                    'invoice_id': current_order.vals_print_fiscal.secuencia,
                    'invoice_date': current_order.vals_print_fiscal.ticket_date,
                    'printer_serial': current_order.vals_print_fiscal.serial,
                })
            resp = to_print.check_pay(sale_list)
            if resp.get('error'):
                _error(current_order.pos_reference, resp.get('sms'))
            _ok(resp.get('sms'), SMS['101'])
        except Exception as exc:
            # return _catch_exception(exc)
            _error([], exc or resp.get('sms'))
