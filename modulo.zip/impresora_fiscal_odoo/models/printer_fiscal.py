# -*- coding: utf-8 -*- 
# Part of Odoo. See LICENSE file for full copyright and licensing details. 
import logging
import re
from odoo import fields, models, api
from odoo.exceptions import ValidationError

logger = logging.getLogger(__name__)

_RETURNS = {
    'error': False,
    'sms': '',
    'data': ''
}
_RETURN_ERRORS = {
    'error': True,
    'sms': '',
    'data': ''
}

SMS = {
    '100': '\n %s MODELO: %s -- %s ==> %s',
    '101': '\n OK SE MANDO A LA IMPRESORA LA NOTA DE CRÉDITO',
    '001': 'No tiene una impresion de factura normal registrada, por tanto, no puede generar Nota de Crédito',

}


def _begin(r):
    logger.info("\n info MODELO: %s -- %s ==> %s | SELF: %s" % (
        'ValsPrinterFiscalPOS', '', r, ''
    ))


def _return_ok(o, r):
    logger.info(SMS['100'] % ('info', 'ValsPrinterFiscalPOS', o, r))
    return r


def _return_err(o, r):
    logger.error(SMS['100'] % ('Error', 'ValsPrinterFiscalPOS', o, r))
    return r


def _ok(data, sms=None):
    RETURNS = _RETURNS.copy()
    RETURNS.update({
        'sms': sms or '',
        'data': data
    })
    _return_ok(RETURNS, RETURNS['sms'])
    return RETURNS


def _error(obj, sms):
    RETURN_ERR = _RETURN_ERRORS.copy()
    RETURN_ERR.update({'sms': sms})
    r = _return_err(obj, RETURN_ERR['sms'])
    raise ValidationError(r)


# class ValsPrinterFiscal(models.Model):
#     _inherit = "account.move"
#
#     def print_invoice_bs(self):
#         return self.env.ref('impresora_fiscal_odoo.report_impresora_fiscal').report_action(self)
#
#     printed_invoice = fields.Selection([('no_printed', 'No'),
#                                         ('printed', 'Si')],
#                                        string='Factura Fiscal Impresa',
#                                        default='no_printed')
#
#     vals_print_fiscal = fields.One2many('vals.printer.fiscal', 'invoice_printer', string='Datos de la Impresión',
#                                         domain="[(id, '=', 'invoice_printer')]")


class ValsPrinterFiscalPOS(models.Model):
    _inherit = "pos.order"

    def print_invoice_bs(self):
        # return self.env.ref('impresora_fiscal_odoo.report_impresora_fiscal').report_action(self)
        try:
            _begin(self)

            # current_order_id = self.env.context.get('active_id')
            current_order_id = self.id
            current_order = self.env['pos.order'].sudo().browse(current_order_id)

            payments = []
            for order_statement in current_order.statement_ids:
                payments.append({
                    'id': order_statement.journal_id.id,
                    'name': order_statement.journal_id.name.upper(),
                    'is_cash_count': order_statement.journal_id.type == 'cash',
                    'use_payment_terminal': False,
                    'currency_payment_method_related': 'VEF' if 'BS' in order_statement.journal_id.name.upper() else 'USD',
                    'is_multi_pay': False,
                    'currency_multi_pay': '',
                    'amount': order_statement.amount
                })

            # if current_order.fiscal_position_id:
            #     return True
            to_print = self.env['stzr.printer.fiscal.to.print'].sudo()
            sale_list = []
            for order_line in current_order.lines:
                sale_list.append({
                    'n_order': str(''.join(re.findall("[0-9-]", current_order.pos_reference))),
                    'product_name': order_line.display_name,
                    'price': order_line.price_unit,
                    # 'price_extra': "x.price_extra",
                    'currency_name': "USD",
                    'quantity': str(int(abs(order_line.qty))),
                    'employee_name': current_order.create_uid.name,
                    'pos_session_name': self.config_id.current_session_id.display_name or '',
                    'client_id': str(current_order.partner_id.id),
                    # 'taxes_id': [tax.description for tax in order_line.tax_ids if 'EXENTO' in tax.description],
                    'taxes_id': [1],
                    'port_printer_name': 'COM' + str(self.config_id.port_printer),
                    'company_id': str(current_order.company_id.id),
                    'payment_methods_json': payments,
                    'invoice_id': current_order.vals_print_fiscal.secuencia or '',
                    'invoice_date': current_order.vals_print_fiscal.ticket_date or '',
                    'printer_serial': current_order.vals_print_fiscal.serial or '',
                })
            resp = to_print.check_pay(sale_list)
            if resp.get('error'):
                _error(current_order.pos_reference, resp.get('sms'))
            _ok(resp.get('sms'), SMS['101'])
        except Exception as exc:
            _error([], exc or resp.get('sms'))

    printed_invoice = fields.Selection([('no_printed', 'No'),
                                        ('printed', 'Si')],
                                       string='Factura Fiscal Impresa',
                                       default='no_printed')

    vals_print_fiscal = fields.One2many('stzr.vals.printer.fiscal.pos.order', 'invoice_printer',
                                        string='Datos de la Impresión')


class ValsPrinterFiscalFields(models.Model):
    _name = "stzr.vals.printer.fiscal.pos.order"
    _description = "Guardar valores de la factura fiscal"

    @api.model
    def create(self, vals):

        if vals['origin'] == 'FAC':
            facturas = self.env['account.move'].sudo().search([('id', '=', vals['invoice_printer'])],
                                                              order='write_date desc')
        if vals['origin'] == 'POS':
            facturas = self.env['pos.order'].sudo().search([('id', '=', vals['invoice_printer'])],
                                                           order='write_date desc')
        del vals['origin']
        if facturas:
            for f in facturas:
                f.write({
                    'printed_invoice': 'printed'
                })
            return super(ValsPrinterFiscalFields, self).create(vals)

    ticket_date = fields.Datetime(string='Fecha de impresión')
    rep_printers = fields.Integer(string='Reimpresiones')
    invoice_printer = fields.Many2one('pos.order', string='Factura #')
    serial = fields.Char('Serial')
    secuencia = fields.Char('Secuencia')
