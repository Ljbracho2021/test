from odoo import fields, models, api


class PosSessionPrinterFiscalModel(models.Model):
    _inherit = "pos.session"

    def _reporte_x_or_z(self, sale):
        to_print = self.env['stzr.printer.fiscal.to.print'].sudo()
        to_print.create(sale)

    def action_print_report_x(self):
        self._reporte_x_or_z({
            'n_order': '',
            'port_printer_name': 'COM' + str(self.config_id.port_printer),  # this.env.pos.config.port_printer,
            'type_invoice': 'reporte_' + 'x',
        })

    def action_print_report_z(self):
        self._reporte_x_or_z({
            'n_order': '',
            'port_printer_name': 'COM' + str(self.config_id.port_printer),  # this.env.pos.config.port_printer,
            'type_invoice': 'reporte_' + 'z',
        })
