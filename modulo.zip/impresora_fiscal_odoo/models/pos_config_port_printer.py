# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models, fields, api


class PortToPrintFiscal(models.Model):
    _inherit = "pos.config"

    port_printer = fields.Integer(string='Puerto de Impresión', default=0)
