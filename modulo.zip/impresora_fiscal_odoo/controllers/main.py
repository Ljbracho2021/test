# -*- coding: utf-8 -*-

from odoo import http
from odoo.http import request
import logging
import ast

_logger = logging.getLogger(__name__)


class PrinterFiscalWebServ(http.Controller):
    @http.route('/write_vals_printer_fiscal', auth="none", type='json')
    def write_vals_printer_fiscal(self, **rec):

        try:
            if request.jsonrequest:
                if rec['invoice_printer']:
                    values = {
                        'invoice_printer': rec['invoice_printer'],
                        'secuencia': rec['secuencia'],
                        'serial': rec['serial'],
                        'ticket_date': rec['ticket_date'],
                        'origin': rec['origin'],
                    }
                    usuario_id = request.env['stzr.vals.printer.fiscal.pos.order'].sudo().create(values)

            return {
                'parametros': usuario_id.id
            }
        except Exception as exc:
            return {
                'error': '%s' % exc
            }
