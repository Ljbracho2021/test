# -*- coding: utf-8 -*-
{
    'name': "impresora_fiscal_odoo",

    'summary': """Manage trainings""",

    'description': """
       Esto esta creado para Odoo v11
    """,

    'author': "Raymond Sanchez",
    'website': "http://www.sistematizarte.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'print',
    'version': '1.2',

    # any module necessary for this one to work correctly
    'depends': ['base', 'point_of_sale'],

    'qweb': [
    ],
    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/vals_printer_fiscal.xml',
        'views/pos_config_port_printer_view.xml',
        'views/pos_session.xml',
    ],
}
