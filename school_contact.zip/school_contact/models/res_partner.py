# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _

class res_partner(models.Model):
    _inherit = 'res.partner'

    
    is_student   = fields.Boolean(string="Es Estudiante", default="True")
    student_id   = fields.Many2one('student.student', 'Estudiante', help='Select student', required=True)
    student_ci   = fields.Char('Identificaciòn', related='student_id.student_id.student_ci', help='Escriba la iIdentificaciòn del estudiante', requied=True)
    student_code = fields.Char('Còdigo', related='student_id.student_id.student_code', help='Escriba el codigo del estudiante', requied=True)
    
    parent_name    = fields.Char('Representante', related='student_id.student_id.parent_name', help='Escriba el codigo del estudiante', requied=True)
    parent_street  = fields.Char('Direcciòn', related='student_id.student_id.parent_street', help='Escriba el codigo del estudiante', requied=True)
    parent_street2 = fields.Char('Direcciòn', related='student_id.student_id.parent_street2', help='Escriba el codigo del estudiante', requied=True)
    parent_city    = fields.Char('Ciudad', related='student_id.student_id.parent_city', help='Escriba el codigo del estudiante', requied=True)
    #parent_state_id = fields.Many2one("res.country.state", string='Estado',related='student_id.student_id.parent_state_id')

    parent_phone   = fields.Char('Telèfono', related='student_id.student_id.parent_phone', help='Escriba el codigo del estudiante', requied=True)
    parent_mobile  = fields.Char('Mòvil', related='student_id.student_id.parent_mobile', help='Escriba el codigo del estudiante', requied=True)
    parent_email   = fields.Char('eMail', related='student_id.student_id.parent_email', help='Escriba el codigo del estudiante', requied=True)
  
    note       = fields.Char('Observaciones')
 
    