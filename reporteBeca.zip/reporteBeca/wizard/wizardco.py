# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class WizardCo(models.TransientModel):
    _name        = 'report.wizardco'
    _description = 'wizardco'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    comuna_id        = fields.Many2one('sala.comuna', string="Comuna", required=True)
    nombre_comuna    = fields.Char(string='Nombre', related='comuna_id.nombre', readonly=True, store=True)
    comunidad_id     = fields.Many2one('sala.comunidad', string="Comunidad", required=True)
    nombre_comunidad = fields.Char(string='Comunidad', related='comunidad_id.nombre', readonly=True, store=True)
    nombre_parroquia = fields.Char(string='Nombre', related='comuna_id.parroquia_id.nombre', readonly=True, store=True)
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]

        salida          = self.env['acciong.lines'].search_read([('comunidad_id','=', self.comunidad_id.id),
                                                                 ('date_apertura', '>=', self.date_start),
                                                                 ('date_cierre', '<', self.date_end),
                                                                 ('state', 'in', ['ejecutada', 'en proceso'])
                                                                ], order ='date_apertura asc, comuna_id asc, comunidad_id asc')
 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteSala.action_report_co').report_action(self, data=data)