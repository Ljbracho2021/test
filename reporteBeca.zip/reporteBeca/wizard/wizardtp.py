# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class WizardTP(models.TransientModel):
    _name = 'report.wizardtp'
    _description = 'Report wizartp'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
       
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]


        parroquiaSet  = self.env['beca.parroquia'].search([], order ='municipio_id asc, nombre asc')
       
        #parroquiaSet  = self.env.cr.execute("select * from base.beca.parroquia;")
        salida    = []

        # conjunto       = self.env['beca.planilla'].search([], order ='create_date asc, create_uid asc, numero asc')

        for indice in parroquiaSet: 

            cantPlani = 0
            cantPlani  = self.env['beca.planilla'].search_count([('parroquia_id','=',indice.id)])

            if cantPlani > 0:
            
                municipio  = indice.municipio_id.nombre
                parroquia  = indice.nombre
                cantidad   = cantPlani

                salida.append({
                    'municipio'    : municipio,
                    'parroquia'    : parroquia,     
                    'cantidad'     : cantidad,
                    'company': self.env.user.company_id
                })

 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteBeca.action_report_tp').report_action(self, data=data)