# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime


from datetime import datetime, timedelta

from odoo import models, fields, api
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT as DATE_FORMAT
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT as DATETIME_FORMAT

class WizardA(models.TransientModel):
    _name = 'report.wizards'
    _description = 'Report Wizarda'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    # state_id      = fields.Selection([('censado', 'CENSADO'), 
    #                                ('becado', 'BECADO')
                                   
    #                               ], string="Status", required=True)

      
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]
        salida    = []

        #salida        = self.env['beca.planilla'].search_read([('state', '=', self.state_id)], order ='numero asc')
        conjunto       = self.env['beca.planilla'].search([], order ='create_date asc, create_uid asc, numero asc')

        for indice in conjunto: 
            
            cedula     = indice.cedula
            numero     = indice.numero
            apellido1  = indice.apellido1
            apellido2  = indice.apellido2
            nombre1    = indice.nombre1
            nombre2    = indice.nombre2
            opcion1_id = indice.opcion1_id.nombre
            opcion2_id = indice.opcion2_id.nombre
            opcion3_id = indice.opcion3_id.nombre
            state      = indice.state
            operador   = indice.create_uid.name
            creado_en  = indice.create_date

            creado_hora = indice.create_date.time()

            hora = creado_hora.isoformat(timespec='auto')

            hora_turno = creado_hora.isoformat(timespec='hours')

            if int(hora_turno) < 14:
               turno = "MAÑANA"
            else:
               turno = "TARDE"

           

            salida.append({
                 'operador'    : operador,
                 'creado_en'   : creado_en,
                 'creado_hora' : hora,
                 'turno'         : turno,
                 'numero'        : numero,         
                 'cedula'        : cedula, 
                 'apellido1'     : apellido1,  
                 'apellido2'     : apellido2, 
                 'nombre1'       : nombre1,                                       
                 'nombre2'       : nombre2,
                 'opcion1_id'    : opcion1_id,
                 'opcion2_id'    : opcion2_id,
                 'opcion3_id'    : opcion3_id,
                 'state'         : state,                
                 'company': self.env.user.company_id
            })


        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteBeca.action_report_s').report_action(self, data=data)