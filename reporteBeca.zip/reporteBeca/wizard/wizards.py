# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class WizardA(models.TransientModel):
    _name = 'report.wizards'
    _description = 'Report Wizards'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)

    state_id         = fields.Selection([('censado', 'CENSADO'), 
                                         ('becado', 'BECADO')
                                   
                                        ], string="Status", required=True)

    modalidad = fields.Selection([
        ('0', 'UNIVERSIDAD PÚBLICA'),
        ('1', 'UNIVERSIDAD PRIVADA'),
        ('2', 'PLATAFORMA EDUCATIVA VIRTUAL'),
    ], required=True, string='Opciones Estudio *', help="Seleccione la Modalidad de Estudios (es campo Obligatorio).")

    

      
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]
        
        salida    = []

        

        conjunto       = self.env['beca.planilla'].search([('state', '=', self.state_id),('modalidad', '=', self.modalidad)], order ='apellido1 asc, apellido2 asc, nombre1 asc, nombre1 asc')

        for indice in conjunto: 
            
            cedula     = indice.cedula
            numero     = indice.name
            apellido   = indice.apellido1 
            if indice.apellido2:
               apellido   = apellido + "," + indice.apellido2
            
            nombre     = indice.nombre1 
            if indice.nombre2:
               nombre   = nombre + "," + indice.nombre2
 
            
            state      = indice.state
            
            salida.append({
                
                 'numero'        : numero,         
                 'cedula'        : cedula, 
                 'apellido'      : apellido,  
                 
                 'nombre'       : nombre,                                       
                 
                 'state'         : state,                
                 'company': self.env.user.company_id
            })

 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteBeca.action_report_s').report_action(self, data=data)