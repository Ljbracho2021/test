# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import calendar, datetime

class WizardA(models.TransientModel):
    _name = 'report.wizards'
    _description = 'Report Wizards'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)

    state_id         = fields.Selection([('censado', 'CENSADO'), 
                                         ('becado', 'BECADO')
                                        ], string="Status", required=True)

   

    modalidad = fields.Selection([
        ('0', 'UNIVERSIDAD PUBLICA'),
        ('1', 'UNIVERSIDAD PRIVADA'),
        ('2', 'PLATAFORMA EDUCATIVA VIRTUAL'),
        ('3', 'TODAS'),

    ], required=True, string='Opciones Estudio *', help="Seleccione la Modalidad de Estudios (es campo Obligatorio).")

    nombreModalidad = fields.Char()
    nombreState     = fields.Char()

    @api.onchange('state_id')
    def _onchange_state_id(self):
         
        if self.state_id:
           #raise ValidationError(_("El valor de  nombreState:" + str(self.nombreState)))
           if self.state_id == "censado":
              self.nombreState = "CENSADO"
           elif self.state_id == "becado":
                self.nombreState = "BECADO"

    @api.onchange('modalidad')
    def _onchange_modalidad(self):
         
        if self.modalidad:
           #raise ValidationError(_("El valor de  nombreState:" + str(self.nombreState)))
           if self.modalidad == "0":
              self.nombreModalidad = "UNIVERSIDAD PUBLICA"
           elif self.modalidad == "1":
                self.nombreModalidad = "UNIVERSIDAD PRIVADA"
           elif self.modalidad == "2":
                self.nombreModalidad = "PLATAFORMA EDUCATIVA VIRTUAL"
           else:   
              self.nombreModalidad = "TODAS LAS MODALIDADES DE ESTUDIO"

    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]
        
        salida    = []
        

        if self.modalidad != "3":
           conjunto = self.env['beca.planilla'].search([('state', '=', self.state_id),('modalidad', '=', self.modalidad)], order ='apellido1 asc, apellido2 asc, nombre1 asc, nombre1 asc')
        else:
           conjunto = self.env['beca.planilla'].search([('state', '=', self.state_id)], order ='apellido1 asc, apellido2 asc, nombre1 asc, nombre1 asc')

        for indice in conjunto: 
            
            cedula     = indice.cedula
            numero     = indice.name
            apellido   = indice.apellido1 
            if indice.apellido2:
               apellido   = apellido + " " + indice.apellido2
            
            nombre     = indice.nombre1 
            if indice.nombre2:
               nombre   = nombre + " " + indice.nombre2
 
            if indice.state == "censado":
               state = "CENSADO"          
            elif indice.state == "becado":
               state = "BECADO"
            elif indice.state == "anulada":
               state = "ANULADA"
 
            salida.append({
                
                 'numero'        : numero,         
                 'cedula'        : cedula, 
                 'apellido'      : apellido,  
                 'nombre'        : nombre,                                       
                 'state'         : state,                
                 'company': self.env.user.company_id
            })

 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteBeca.action_report_s').report_action(self, data=data)