# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class Wizard(models.TransientModel):
    _name = 'report.wizard'
    _description = 'Report Wizard'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    carrera_id       = fields.Many2one('beca.carrera', string="Carrera", required=True)
    nombre_carrera    = fields.Char(string='Nombre', related='carrera_id.nombre', readonly=True, store=True)

    modalidad = fields.Selection([
        ('0', 'UNIVERSIDAD PUBLICA'),
        ('1', 'UNIVERSIDAD PRIVADA'),
        ('2', 'PLATAFORMA EDUCATIVA VIRTUAL'),
    ], required=True, string='Opciones Estudio *', help="Seleccione la Modalidad de Estudios (es campo Obligatorio).")

    nombreModalidad = fields.Char()
    #nombre_parroquia = fields.Char(string='Nombre', related='comuna_id.parroquia_id.nombre', readonly=True, store=True)
    
    @api.onchange('modalidad')
    def _onchange_modalidad(self):
         
        if self.modalidad:
           if self.modalidad == "0":
              self.nombreModalidad = "UNIVERSIDAD PUBLICA"
           elif self.modalidad == "1":
              self.nombreModalidad = "UNIVERSIDAD PRIVADA"
           else:   
              self.nombreModalidad = "PLATAFORMA EDUCATIVA VIRTUAL"
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]

        salida    = []

        # salida          = self.env['beca.planilla'].search_read(['|',('opcion1_id','=', self.carrera_id.id),('opcion2_id','=', self.carrera_id.id),'|',('opcion3_id','=', self.carrera_id.id),
        #                                                            ('state', 'in', ['censado', 'becado'])
        #                                                         ], order ='opcion1_id asc')

        conjunto          = self.env['beca.planilla'].search(['&','|','|',('opcion1_id','=', self.carrera_id.id),
                                                                               ('opcion2_id','=', self.carrera_id.id),
                                                                               ('opcion3_id','=', self.carrera_id.id),
                                                                               ('state', 'in', ['censado', 'becado'])
                                                                ], order ='apellido1 asc, apellido2 asc, nombre1 asc, nombre2 asc')

        for indice in conjunto: 
            
            cedula     = indice.cedula
            numero     = indice.name
            apellido   = indice.apellido1 
            opcion1    = indice.opcion1_id.nombre
            opcion2    = indice.opcion2_id.nombre
            opcion3    = indice.opcion3_id.nombre

            if indice.apellido2:
               apellido   = apellido + "," + indice.apellido2
            
            nombre     = indice.nombre1 
            if indice.nombre2:
               nombre   = nombre + "," + indice.nombre2
 
            
            state      = indice.state
            
            salida.append({
                
                 'numero'        : numero,         
                 'cedula'        : cedula, 
                 'apellido'      : apellido,  
                 'nombre'       : nombre,                                       
                 'opcion1'       : opcion1,
                 'opcion2'       : opcion2,
                 'opcion3'       : opcion3,

                 'state'         : state,                
                 'company': self.env.user.company_id
            })

       

        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteBeca.action_report').report_action(self, data=data)