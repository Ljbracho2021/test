# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class WizardC(models.TransientModel):
    _name = 'report.wizardc'
    _description = 'Report Wizardc'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    modalidad = fields.Selection([
        ('0', 'UNIVERSIDAD PÚBLICA'),
        ('1', 'UNIVERSIDAD PRIVADA'),
        ('2', 'PLATAFORMA EDUCATIVA VIRTUAL'),
    ], required=True, string='Opciones Estudio *', help="Seleccione la Modalidad de Estudios (es campo Obligatorio).")

    nombre_moda = fields.Char()

      
    
    #--------------------------------------------------------------------------------#
    #  VALIDACIONES PARA EL NUMERO DE TELEFONO                                       #
    #--------------------------------------------------------------------------------#
    @api.onchange('modalidad')
    def _onchange_modalidad(self):
        if not self.modalidad:
            return

        if self.modalidad == "0":
           self.nombre_moda="UNIVERSIDAD PÚBLICA"
        if self.modalidad == "1":
           self.nombre_moda="UNIVERSIDAD PRIVADA"
        if self.modalidad == "2":
           self.nombre_moda="PLATAFORMA EDUCATIVA VIRTUAL"
    
    
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]


        salida          = self.env['beca.carrera'].search_read([('modalidad','=',self.modalidad)], order ='nombre asc')
 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteBeca.action_report_c').report_action(self, data=data)