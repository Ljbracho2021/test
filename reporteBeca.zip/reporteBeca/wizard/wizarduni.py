# -*- coding: utf-8 -*-

from email.policy import default

from pkg_resources import require
from odoo import api, fields, models
import calendar, datetime

class WizardUni(models.TransientModel):
    _name = 'report.wizarduni'
    _description = 'Wizarduni'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    unidad_id        = fields.Many2one('sala.unidad', string="Unidad", required=True)
    nombre_unidad    = fields.Char(string='Nombre', related='unidad_id.nombre', readonly=True, store=True)
 
    def primer_dia_mes(self):
        now   = datetime.datetime.now()
        year  = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now   = datetime.datetime.now()
        year  = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]

        salida          = self.env['acciong.lines'].search_read([('unidad_id','=', self.unidad_id.id),
                                                                 ('date_apertura', '>=', self.date_start),
                                                                 ('date_cierre', '<', self.date_end),
                                                                 ('state', 'in', ['ejecutada', 'en proceso'])
                                                                ], order ='date_apertura asc, comuna_id asc, comunidad_id asc') 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteSala.action_report_uni').report_action(self, data=data)