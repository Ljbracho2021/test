# -*- coding: utf-8 -*-

from . import wizard
from . import wizarda
#from . import wizardco
#from . import wizardcc
#from . import wizardon