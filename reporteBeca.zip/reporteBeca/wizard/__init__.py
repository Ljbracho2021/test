# -*- coding: utf-8 -*-

from . import wizard
from . import wizarda
from . import wizards
#from . import wizardcc
#from . import wizardon