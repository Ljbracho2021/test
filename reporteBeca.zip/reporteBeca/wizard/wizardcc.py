# -*- coding: utf-8 -*-

from email.policy import default

from pkg_resources import require
from odoo import api, fields, models
import calendar, datetime

class Wizardcc(models.TransientModel):
    _name = 'report.wizardcc'
    _description = 'Wizardcc'

    date_start       = fields.Date('Fecha Inicio')
    date_end         = fields.Date('Fecha Fin')
    ejercicio_id     = fields.Many2one('presupuesto.ejercicio', string="Ejercicio", required=True)
    nombre_ejercicio = fields.Char(string='Nombre ejercicio', related='ejercicio_id.nombre', readonly=True, store=True)
    centrocosto_id     = fields.Many2one('presupuesto.centrocosto', string="Centro costo", required=True)
    nombre_centrocosto = fields.Char(string='Nombre centro costo', related='centrocosto_id.ltext', readonly=True, store=True)   
    moneda_id        = fields.Many2one('presupuesto.moneda', string="Moneda", required=True)
    nombre_moneda    = fields.Char(string='Nombre moneda', related='moneda_id.name', readonly=True, store=True)
    simbolo_moneda   = fields.Char(string='Sìmbolo', related='moneda_id.simbolo', readonly=True, store=True)
    valor_tasa       = fields.Float(string='Tasa', required=True, default=0, compute="_value_pc")
    presupuesto_id   = fields.Many2one('presupuesto.presupuesto', string="Presupuesto")
    version_id       = fields.Many2one('presupuesto.version', 'Versión')
    nombre_version   = fields.Char(string='Nombre versiòn', related='version_id.nombre', readonly=True, store=True)

    def primer_dia_mes(self):
        now   = datetime.datetime.now()
        year  = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now   = datetime.datetime.now()
        year  = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    @api.depends('moneda_id')
    def _value_pc(self):
        for record in self:
            tipo_cotiza = self.env['presupuesto.tasa'].search([('moneda_id','=', self.moneda_id.name)])
            if tipo_cotiza:
               record.valor_tasa = tipo_cotiza.valor
            else:
               valor_tasa = 0

    def action_search_salida(self):
        form_data = self.read()[0]

        presupuesto     = self.env['presupuesto.presupuesto'].search([('ejercicio_id','=', self.ejercicio_id.id)])
        version         = self.env['presupuesto.version'].search([('name','=', 'O01')])
        self.date_start = presupuesto.date_apertura
        self.date_end   = presupuesto.date_cierre
        salida          = self.env['presupuesto.presupuesto.detalles'].search_read([('presupuesto_id','=', presupuesto.id),('version_id','=', version.name),('objnr_id','=', self.centrocosto_id.name)])
 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporte.action_report_cc').report_action(self, data=data)