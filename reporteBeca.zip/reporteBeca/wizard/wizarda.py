# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class WizardA(models.TransientModel):
    _name = 'report.wizarda'
    _description = 'Report Wizarda'

    date_start       = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end         = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    state      = fields.Selection([('censado', 'CENSADO'), 
                                   ('becado', 'BECADO'),
                                   ('anulada', 'ANULADA')
                                  ], string="Status")

      
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)

    def action_search_salida(self):
        form_data = self.read()[0]


        salida          = self.env['beca.planilla'].search_read([('state', '=', self.state)], order ='numero asc')
 
        data = {
            'form_data': form_data,
            'salida'   : salida
        }

        return self.env.ref('reporteBeca.action_report_a').report_action(self, data=data)