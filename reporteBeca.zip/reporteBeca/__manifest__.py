# -*- coding: utf-8 -*-
{
    'name': "3Par1 Beca Reports",
    'summary': "Reports with custom header and footer",
    'description': """

Reports sample with custom header and footer
""",
    'author': "3Par1 Corp",
    'category': 'Uncategorized',
    'version': '15.0.22.04.20',
    'website': "https://www.3par1.com",
    'depends': ['base',
                '3par1_beca'],
    'license': 'AGPL-3',
    'data': [
        'report/report.xml',
        'report/reporta.xml',
        'report/reports.xml',
        'report/reportc.xml',  
        'report/reportm.xml',
        'report/reportp.xml', 
        'report/reporttp.xml',
        'report/reportb.xml',

        
        'security/ir.model.access.csv',
        'wizard/wizard.xml',
        'wizard/wizarda.xml',
        'wizard/wizards_view.xml',
        #'wizard/wizardc_view.xml',
        #'wizard/wizardm_view.xml',
        #'wizard/wizardp_view.xml',
        #'wizard/wizardtp_view.xml',
        #'wizard/wizardb_view.xml',
    ],
    'images': [
        'static/description/icon.jpg'
    ],
}