# -*- coding: utf-8 -*-
{
    'name': "School Reports",
    'summary': "Reports odooClass",
    'description': """

Reports OdooClass
""",
    'author': "IT Soluciones WEB",
    'category': 'Uncategorized',
    'version': '16.1',
    'website': "https://www.itsolucionesweb.com",
    'depends': ['base',
                'school'],
    'license': 'AGPL-3',
    'data': [
        'report/report.xml',

        'security/ir.model.access.csv',
        'wizard/wizard.xml',
        
    ],
    'images': [
        'static/description/icon.jpg'
    ],
}