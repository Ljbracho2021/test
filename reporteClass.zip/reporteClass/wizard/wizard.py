# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class Wizard(models.TransientModel):
    _name = 'report.wizard'
    _description = 'Report Wizard'

    date_start      = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end        = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    student_id      = fields.Many2one('student.student', string="Estudiante", required=True)
    #inscripcion_ids = fields.One2many('student.inscripcion', 'student_id', 'RI', related='student_id.inscripcion_ids', store=True, help='Students which are in this standard')
    inscripcion_id  = fields.Many2one('student.inscripcion', 'Secciòn', help='Selecione la secciòn', required=True)
    #nombre_carrera   = fields.Char(string='Nombre', related='carrera_id.nombre', readonly=True, store=True)

    # nombreModalidad = fields.Char()
    # #nombre_parroquia = fields.Char(string='Nombre', related='comuna_id.parroquia_id.nombre', readonly=True, store=True)
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)
    
#-----------------------------------------------------------------------#
    def get_escala(self):
        '''Method to compute la escala minima.'''

        califica_vals = {'minimo': 0, 'maximo': 0 , 'aprobado': 0 }
  
        escalaObj = self.env['grade.line'].sudo().search([('sequence', '=', '1')], limit=1)

        if escalaObj:
           califica_vals = {'minimo': escalaObj.from_mark, 
                            'maximo': escalaObj.to_mark,
                            'aprobado': escalaObj.pass_mark
                           }
        
        return califica_vals
    
#-----------------------------------------------------------------------#
    def get_estado(self , sta):
        '''Method to compute la escala minima.'''

        if sta == 'draft':
           return 'POR INICIAR'
        elif sta == 'done':
           return 'INICIADO' 
        elif sta == 'terminate':
           return 'CULMINADO'
        elif sta == 'aprobado':
           return 'APROBADO'
        elif sta == 'aplazado':
           return 'APLAZADO'
        else:
            return sta
        
        return sta
    
#-----------------------------------------------------------------------#
    def action_search_salida(self):
        form_data = self.read()[0]

        est    = []
        eva    = []
        asi    = []
        pro    = []

        no_eva      = 0
        i           = 1
        j           = 1
        r           = 1

        acumOralStu = 0
        acumEscStu  = 0
        contaEva    = 0
        contaAsi    = 0
        contaAsiste = 0

        promeO      = 0
        promeE      = 0
        promeT      = 0
        promeA      = 0

        calificaVals = self.get_escala()

        stuObj = self.env['student.student'].search([('student_id','=', self.student_id.id)] , order ='name asc')

        riObj = self.env['student.inscripcion'].search([('id','=', self.inscripcion_id.id)] , order ='name asc')

        if stuObj: 
            
             cedula     = stuObj.student_ci
             codigo     = stuObj.student_code
             nombre     = stuObj.name
             seccion    = riObj.standard_id.name
             curso      = riObj.standard_id.subject_id.name
             estado     = self.get_estado(riObj.state)

             est.append({      
                            'cedula'        : cedula,  
                            'codigo'        : codigo, 
                            'nombre'        : nombre, 
                            'seccion'       : seccion,
                            'curso'         : curso,
                            'estado'        : estado,
                      
                            #'company': self.env.user.company_id
                          })
             
             if riObj:
                 
                 seccion     = riObj.standard_id.name
                 arreEva     = riObj.standard_id.evaluacion_ids
                 no_eva      = len(riObj.standard_id.evaluacion_ids)
                 no_asi      = len(riObj.standard_id.asistencia_ids)

                #-----------------------------------------------------------------------#
                # CICLO EVALUACIONES DE LA SECCION                                      #
                #-----------------------------------------------------------------------#
                 j       = 1
                 while j <= no_eva:
                        
                    if riObj.standard_id.evaluacion_ids[j-1].state == 'terminate':
                        
                        reObj   = riObj.standard_id.evaluacion_ids[j-1].evaluacion_ids
                        no_evas = len(reObj)
                        
                        #-----------------------------------------------------------------------#
                        # CICLO DETALLES DE EVALUACIONES DE LA SECCION                          #
                        #-----------------------------------------------------------------------#

                        r = 1
                        while r <= no_evas:
                            if stuObj.id == reObj[r-1].student_id.id:

                                contaEva = contaEva + 1

                                nombreEva = reObj.evaluacion_id.name
                                evaO      = reObj[r-1].eva_oral
                                evaE      = reObj[r-1].eva_esc
                                evaRO     = reObj[r-1].rec_oral
                                evaRE     = reObj[r-1].rec_esc
                                evaT      = reObj[r-1].eva_total
                                nombreSta = reObj[r-1].state
                                nombreSta = self.get_estado(reObj.evaluacion_id.state)
                                nombreCal = self.get_estado(reObj[r-1].state)
                                
                                if reObj[r-1].is_recupera and reObj[r-1].rec_oral > 0:
                                    acumOralStu += reObj[r-1].rec_oral
                                else:
                                    acumOralStu += reObj[r-1].eva_oral

                                if reObj[r-1].is_recupera and reObj[r-1].rec_esc > 0:
                                    acumEscStu += reObj[r-1].rec_esc
                                else:
                                    acumEscStu += reObj[r-1].eva_esc    
                            
                            r = r + 1
                        
                        eva.append({      
                                    'nombreEva' : nombreEva,         
                                    'eva_o'     : evaO, 
                                    'eva_e'     : evaE,
                                    'eva_ro'    : evaRO,
                                    'eva_re'    : evaRE,
                                    'eva_t'     : evaT,
                                    'nombreSta' : nombreSta,
                                    'nombreCal' : nombreCal,

                                    #'company': self.env.user.company_id
                                   })

                    j = j + 1
                        
                #-----------------------------------------------------------------------#
                # CICLO ASISTENCIA DE LA SECCION                                      #
                #-----------------------------------------------------------------------#
                 j       = 1
                 while j <= no_asi:
                        
                    if riObj.standard_id.asistencia_ids[j-1].state == 'terminate':
                        
                        raObj   = riObj.standard_id.asistencia_ids[j-1].asistencia_ids
                        no_detalle_asi  = len(raObj)

                        #-----------------------------------------------------------------------#
                        # CICLO DETALLES DE ASISTENCIA DE LA SECCION                          #
                        #-----------------------------------------------------------------------#

                        r = 1
                        nombreAsi = ''
                        is_asistio = False
                        while r <= no_detalle_asi:
                            if stuObj.id == raObj[r-1].student_id.id:
                                contaAsi = contaAsi + 1
                                nombreAsi  = raObj.asistencia_id.name
                                nombreSta  = self.get_estado(raObj.asistencia_id.state)
                                
                                if raObj[r-1].is_attended:
                                    contaAsiste = contaAsiste + 1
                                    is_asistio = 'ASISTENTE'
                                else:
                                    is_asistio = 'INASISTENTE'
                             
                            r = r + 1
                       
                        asi.append({      
                                    'nombreAsi' : nombreAsi, 
                                    'nombreSta' : nombreSta, 
                                    'is_asistio': is_asistio, 
                                    
                                    #'company': self.env.user.company_id
                                   })
                        
                    j = j + 1
                        
        nombreSta = ''
        if contaEva !=0:
                promeO = acumOralStu/contaEva
                promeE = acumEscStu/contaEva
                promeT = (promeO + promeE)/2
                nombreSta = ''

                if promeO >= calificaVals['aprobado'] and promeE >= calificaVals['aprobado']:
                    nombreSta = 'APROBADO'
                else:
                    nombreSta = 'APLAZADO'

        if contaAsi !=0:
            promeA = (contaAsiste/contaAsi)*100

        pro.append({      
                    'promeO'    : promeO,   
                    'promeE'    : promeE,
                    'promeT'    : promeT,
                    'promeA'    : promeA,
                    'nombreSta' : nombreSta,

                    #'company': self.env.user.company_id
                   })
        
        data = {
            'form_data': form_data,
            'est'   : est,
            'eva'   : eva,
            'asi'   : asi,
            'pro'   : pro
        }

        return self.env.ref('reporteClass.action_report').report_action(self, data=data)