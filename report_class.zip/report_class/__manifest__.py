# -*- coding: utf-8 -*-
{
    'name': "School Reports",
    'summary': "Reports odooClass",
    'description': """

Reports OdooClass
""",
    'author': "IT Soluciones WEB",
    'category': 'Uncategorized',
    'version': '16.1',
    'website': "https://www.itsolucionesweb.com",

    'depends': ['base',
                'school',
                'report_xlsx'
               ],

    'license': 'AGPL-3',

    'data': [
        'data/paper_format.xml',

        'report/report.xml',
        'report/report_record_template.xml',
        'report/report_invoice_recibo.xml',
        'report/report_record_ce_template.xml',
        'report/report_record_fi_template.xml',
        'report/report_record_pr_template.xml',

        'report/report_invoice_student.xml',

        'views/admin_view.xml',

        'security/ir.model.access.csv',

        'wizard/wizard.xml',
        'wizard/wizard_ce.xml',
        'wizard/wizard_fi.xml',
        'wizard/wizard_pr.xml',
        
    ],

    'images': [
        'static/description/icon.jpg'
    ],
}