from odoo import models
class PartnerXlsx(models.AbstractModel):

    _name    = 'report.report_class.partner_xlsx'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, partners):
        row  = 1
        col  = 0
        tira = ""
        # Create a workbook and add a worksheet.
        
        worksheet = workbook.add_worksheet('HOJA MOODLE')
        bold  = workbook.add_format({'bold': True})

        tira = "username,password,firstname, lastname,email,city,country,lang,course1,role1,enrolperiod,enrolstatus"
        worksheet.write(0, col, tira, bold)

        for obj in partners:
            
            partner_xlsx = obj.name

            tira = obj.student_id.student_code + "," + "1234" + "," + obj.student_id.name + "," + obj.student_id.email + "," + "eng" + "," + obj.subject_id.code_moodle + "," + "student" + "," + "150" + "," + "0" 

            worksheet.write(row, col, tira, bold)
            
            row+=1