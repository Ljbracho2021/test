# -*- coding: utf-8 -*-

from . import wizard
from . import wizard_ce
from . import wizard_fi
from . import wizard_pr
from . import wizard_as
from . import wizard_in
from . import wizard_ca