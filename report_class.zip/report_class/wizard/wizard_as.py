# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError
import calendar, datetime

class Wizard(models.TransientModel):
    _name        = 'report.wizard_as'
    _description = 'Report Wizard Inasistencias'

    date_today   = fields.Date('Fecha Informe', default=fields.Date.today )
    date_start   = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end     = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)
    
#-----------------------------------------------------------------------#
    def action_search_salida(self):
        form_data = self.read()[0]

        asi    = []
     
        no_ina      = 0
        j           = 1

        asi_obj = self.env['subject.asistencias'].search([] , order ='date_start asc')
     
        #raise ValidationError("no_student:" + str(no_ina))
        if asi_obj: 
           
           line_ina = asi_obj.filtered(lambda x: not x.is_attended and x.date_start >= self.date_start and x.date_start <= self.date_end and x.state == 'terminate')
           
           no_ina   = len(line_ina)
           #raise ValidationError("no_student:" + str(no_ina))
           j       = 1
           while j <= no_ina:
                        
               codeStu    = line_ina[j-1].student_id.student_code
               nombreStu  = line_ina[j-1].student_id.name
               nombreSec  = line_ina[j-1].standard_id.code + "/" + line_ina[j-1].standard_id.subject_id.nombre
               nombreCam  = line_ina[j-1].standard_id.school_id.name
               nombreEnc  = line_ina[j-1].encuentro_id.name
               fechaEnc   = line_ina[j-1].date_start

               asi.append({       
                            'codeStu'   : codeStu,
                            'nombreStu' : nombreStu,
                            'nombreSec' : nombreSec, 
                            'nombreCam' : nombreCam, 
                            'nombreEnc' : nombreEnc, 
                            'fechaEnc'  : fechaEnc, 
                                    
                            #'company': self.env.user.company_id
                          })
                        
               j = j + 1
        
        data = {
            'form_data': form_data,
            'asi'   : asi,
        }

        return self.env.ref('report_class.action_report_informe_ina').report_action(self, data=data)