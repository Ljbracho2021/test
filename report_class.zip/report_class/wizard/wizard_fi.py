# -*- coding: utf-8 -*-

from email.policy import default
from odoo import api, fields, models
import calendar, datetime

class Wizard(models.TransientModel):
    _name = 'report.wizard_fi'
    _description = 'Report Wizard / Constancia de Estudios'

    date_start      = fields.Date('Fecha Inicio', required=True, default=fields.Date.today )
    date_end        = fields.Date('Fecha Fin', required=True, default=fields.Date.today)
    student_id      = fields.Many2one('student.student', string="Estudiante", required=True)
    # inscripcion_id  = fields.Many2one('student.inscripcion', 'Secciòn', help='Selecione la secciòn', required=True)
    
    def primer_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        return datetime.date(year,month,1)

    def ultimo_dia_mes(self):
        now = datetime.datetime.now()
        year = now.year
        month = now.month
        last_day = calendar.monthrange(year, month)[1] ## último día

        return datetime.date(year,month,last_day)
    
#-----------------------------------------------------------------------#
    def get_escala(self):
        '''Method to compute la escala minima.'''

        califica_vals = {'minimo': 0, 'maximo': 0 , 'aprobado': 0 }
  
        escalaObj = self.env['grade.line'].sudo().search([('sequence', '=', '1')], limit=1)

        if escalaObj:
           califica_vals = {'minimo': escalaObj.from_mark, 
                            'maximo': escalaObj.to_mark,
                            'aprobado': escalaObj.pass_mark
                           }
        
        return califica_vals
    
#-----------------------------------------------------------------------#
    def get_estado(self , sta):
        '''Method to compute la escala minima.'''

        if sta == 'draft':
           return 'POR INICIAR'
        elif sta == 'done':
           return 'INICIADO' 
        elif sta == 'terminate':
           return 'CULMINADO'
        elif sta == 'aprobado':
           return 'APROBADO'
        elif sta == 'aplazado':
           return 'APLAZADO'
        else:
            return sta
        
        return sta
    
#-----------------------------------------------------------------------#
    def action_search_salida(self):
        form_data = self.read()[0]

        est    = []
        cur    = []
        act    = []
        asi    = []
        pro    = []

        no_eva      = 0
        i           = 1
        j           = 1
        r           = 1

        acumOralStu = 0
        acumEscStu  = 0
        acumEva     = 0
        contaEva    = 0
        contaAsi    = 0
        contaAsiste = 0

        promeO      = 0
        promeE      = 0
        promeT      = 0
        promeA      = 0

        calificaVals = self.get_escala()

        stuObj = self.env['student.student'].search([('id','=', self.student_id.id)] , order ='name asc')

        riObj = self.env['student.inscripcion'].search([('student_id','=', self.student_id.id),('state','in', ['terminate'])] , order ='name asc')

        if stuObj: 
            
             cedula     = stuObj.student_ci
             codigo     = stuObj.student_code
             nombre     = stuObj.name
             seccion    = riObj.standard_id.code +  '-' + riObj.standard_id.name
             curso      = riObj.standard_id.subject_id.nombre
             schedule   = riObj.standard_id.note
             signature  = riObj.standard_id.company_id.director_signature
             director   = riObj.standard_id.company_id.director_name
             director_id = riObj.standard_id.company_id.director_id
             director_job = riObj.standard_id.company_id.director_job
             empresa    = riObj.standard_id.company_id.name
             programa   = riObj.standard_id.subject_id.programa_id.name
             estado     = self.get_estado(riObj.state)

             est.append({      
                            'cedula'        : cedula,  
                            'codigo'        : codigo, 
                            'nombre'        : nombre, 
                            'seccion'       : seccion,
                            'curso'         : curso,
                            'schedule'      : schedule,
                            'signature'     : signature,
                            'director'      : director,
                            'director_id'   : director_id,
                            'director_job'  : director_job,
                            'empresa'       : empresa,
                            'programa'      : programa,

                            'estado'        : estado,
                      
                          })

             
             if riObj:
                 

                 no_cur      = len(riObj)
                 

                #-----------------------------------------------------------------------#
                # CICLO CURSOS                                                          #
                #-----------------------------------------------------------------------#
                 j       = 1
                 while j <= no_cur:
                    curso     = riObj[j-1].subject_id.nombre
                    seccion   = riObj[j-1].standard_id.name
                    nota      = riObj[j-1].nota
                    status    = riObj[j-1].state_eva
                  
                    cur.append({      
                                'curso'    : curso, 
                                'seccion'  : seccion, 
                                'nota'     : nota,
                                'status'   : status

                                })
                        
                    j = j + 1
                        
         
        data = {
            'form_data': form_data,
            'est'   : est,
            'cur'   : cur,
        }

        return self.env.ref('report_class.action_report_record_fi').report_action(self, data=data)